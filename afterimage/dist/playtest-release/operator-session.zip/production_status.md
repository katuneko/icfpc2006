# Afterimage production status

This is the live, evidence-backed production ledger. Design totals describe
the intended product; only items under **Verified now** exist as runnable
content.

## Verified now

- Product design: 75 cases and 10,000 nominal points remain internally
  consistent.
- Vertical-slice design: 12 cases and 1,200 nominal points; all cases are
  reachable and the reveal has two minimal paths.
- CRE 0.1: Python and JavaScript agree on 37 cases, seven hostile canonical
  inputs, 35 semantic assertions, NDJSON behavior, and public-oracle digest
  `2cb50ac46b8415ddc4e195e238b7ad73a2f87de8ae106ef8a1006e0ea6bf55ec`.
  Three focused tests prove both references pass the shipped checker, error
  prose is non-normative, and a bad engine receives its first JSON-Pointer
  mismatch instead of only an opaque aggregate digest.
- Bundle security: 14 tests cover reproducibility, path and link attacks,
  canonical files, resource limits, corruption, and extracted-world drift.
- Witness verifier: nine focused tests plus the content suite cover schema,
  policy, branch, replay, claimed digests, ORIENT/CASCADE/MERGE/PULSE scoring,
  unlocks, non-leaking diagnostics, and policy-checked non-root histories that
  avoid bundle/BranchId self-reference.
- PULSE runtime: four focused tests cover its 3,304-case exhaustive domain,
  same-tick input priority, keyed timer replacement, static types, bounded
  resource failure, and standalone helper discovery.
- MOSAIC verifier: three focused tests cover D4 canonicalization, complete
  attributed-grid coverage, and rejection of unsupported decoy claims.
- LENS checker: three focused tests cover 72 sources by 15 edits, boundary
  ambiguity, complement preservation, invalid-edit atomicity, and stable law
  counterexamples.
- COVENANT checker: six focused tests exhaust every fair schedule in a finite
  asynchronous model, enforce local observation, safety, bounded liveness,
  finite domains and hard resource ceilings, and exercise authoritative host
  scoring. The reference dispatch policy reaches 32 augmented states with
  worst response bound 5.
- PARADOX checker: five focused tests and a complete authoritative-verifier
  fixture independently replay two policy-checked histories, prove exact
  public-record equivalence and safety evidence, require a non-zero latent
  difference, and score all three certificate metrics.
- Authored content: ORIENT.001–005, CASCADE.001–003, MERGE.001, PULSE.001,
  MOSAIC.001, and LENS.001, totaling 1,200 points. Fifteen production tests
  cover deterministic builds, author baselines, case-world isolation, label
  resolution, causal replay auditing, projection semantics, root/candidate
  differences, derived-target diagnostics, independently verified exports,
  capability grants, exact order certificates, supported rejection reasons,
  scoped capability enforcement, private-payload non-disclosure, and hostile
  answer mutations.
- Player workspace: nine focused tests cover canonicalization of editor JSON,
  raw-cost tie breaking, initial visibility, monotone
  unlocks, all twelve author receipts, 1,121/1,200 aggregate author score,
  case/event inspection, root branch snapshots, comparisons, hints,
  destructive reset, byte-for-byte replay from retained witnesses, and
  rejection of support-directory symlinks before any write. Branch commands
  can carry a verified parent history by BranchId or canonical history file.
- Playtest release: reproducible engine, game, and operator zip packages are
  physically separated. The engine package has no reference evaluator; both
  participant packages exclude author witnesses, case sources, author golden
  data, and authoring tools. The engine package intentionally contains only
  the public CRE conformance oracle. The staged game package boots with an empty `PATH` and
  networking is not required. The operator package includes a dependency-
  closed campaign analyzer and exact observation contract.
- Playtest decision gate: seven focused tests cover private draft generation,
  random anonymous codes, balanced cohorts, complete missing-field reporting,
  a passing six-team campaign, exact half-minute median and nearest-rank P90,
  censored receipt timing, ratio scaling above six teams, all eight stop-and-
  redesign triggers, strict controlled fields, canonicalization, and immutable
  output. This validates the decision mechanism only; it supplies no human
  evidence.
- Telemetry: disabled by default and consent-gated. Exported events have
  monotone ticks/timestamps and allow only command class, public error code,
  hint level, counts, scores, metrics, and unlocks; tests exclude answer,
  intervention, parent-branch, event-ID, and submission bytes.
- Adversarial simulation: six isolated AI agents in two fresh waves exercised
  independent CRE implementation, localized conformance, offline progression,
  score improvement, and receipt replay. The simulation drove fixes for the
  public oracle and fixture contract, editor JSON, helper launch, raw-cost
  tie-breaking, trace rendering, and complete branch-trace access. This is
  engineering evidence only and supplies no human acceptance or timing data;
  see `playtest/AI_SIMULATION_2026-07-15.md`.
- AI proxy acceptance: six new isolated low/medium/high behavioral-proxy
  conditions produced a canonical `proxy-pass`. All six solved CASCADE.003
  without hints, explained the projection boundary, improved valid metrics,
  and replayed losslessly; independent solutions cover all six slice families.
  Estimated first receipt is median 40 minutes and P90 50. The 1.5x timing
  sensitivity is `revise` because its median becomes 60, so timing remains a
  documented risk. Three independently implemented proxy engines passed a
  private renamed-fixture generalization check; two public-oracle adapters
  were detected and excluded from engine-completion evidence.

The current development bundle is reproducible with:

```text
archive sha256  d392f575e41d42f5ccbfae221fabf5ea2d5638a5b6e0aa777ad96ab6755d5ac6
bundle id       sha256:edf8f32b5c0836b5adebe587ad690712b81d0df8082cb2f1ac44bff5d241fd27
logical files   137
base events     54
rules           23
projections     12
```

Run the complete gate with:

```bash
python3 afterimage/tools/check_all.py
```

## Coverage

| Scope | Runnable | Designed | Runnable points |
| --- | ---: | ---: | ---: |
| Onboarding ORIENT cases | 5 | 5 | 300 / 300 |
| Vertical slice | 12 | 12 | 1,200 / 1,200 |
| Full problem set | 12 | 75 | 1,200 / 10,000 |

ORIENT.001 fixes event identity and provenance. ORIENT.002 checks parent order,
same-time EventId order, and least-fixed-point replay. ORIENT.003 proves that a
projection is an observation and does not delete unreported active events.
ORIENT.004 retimes a base cause and verifies the exact root/counterfactual
active-set difference after all derived events are recomputed.
ORIENT.005 independently replays an embedded prior witness and grants
`cap:audit.export` only after the portable claim verifies.
CASCADE.001 compares retime, suppression, and reroute policies under explicit
safety/service contracts and lexicographic intervention scoring.
MERGE.001 reconstructs eight of nine clock-drift records, proves the active
message/source order with 12 exact certificate edges, and supports both a
two-record conflict-set baseline and the one-record optimal isolation.
PULSE.001 compiles a 485-byte typed controller with one live deadline cell,
replaces keyed timers, and proves exact output over all 3,304 bounded inputs;
its golden author score is 135/150.
CASCADE.002 verifies pressure, route, capacity, evidence retention,
maintenance-window, and energy contracts. Its two-retime author repair scores
99/100 and beats the separately verified pump-dispatch baseline.
MOSAIC.001 reconstructs a canonical 9-vertex/12-edge grid from four differently
oriented fragments, proves full coverage, and excludes only the independently
non-embeddable weight-1 decoy; its author score is 129/130.
LENS.001 checks 1,080 valid source/edit pairs plus invalid edits against four
round-trip/provenance laws. Its 32-node, 3-cell complement program scores
177/180.
CASCADE.003 proves that relay `v4-v7` remains in the active causal state while
its public projection suppresses the entire restricted event. The author
witness uses no intervention, leaks no private payload, and scores 139/140;
the verifier accepts the scoped audit capability as a costlier alternative
and rejects the same capability outside this case's scope.

## Remaining gates

1. Implement the remaining 63 designed cases. The user-authorized AI proxy
   campaign opened this production gate on 2026-07-16; no human campaign is
   claimed. The non-root history mechanism and COVENANT/PARADOX
   verifier/scoring substrates are ready, but no full-production case in those
   families is authored yet.

The current verifier now scores all eight designed families: ORIENT, CASCADE,
MERGE, PULSE, MOSAIC, LENS, COVENANT, and PARADOX. Non-root histories are
replayed from canonical policy-checked operation chains. Design entries beyond
the twelve authored slice cases still lack production content and author
baselines.
