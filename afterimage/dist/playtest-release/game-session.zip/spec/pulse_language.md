# PULSE 0.1 language and exhaustive execution

Status: normative for `afterimage-pulse/0.1` vertical-slice programs.

PULSE is a bounded event-handler language for small temporal controllers. It
has typed scalar cells, immutable source events, replaceable keyed timers, and
no iteration or host callbacks. A verifier MUST reject programs or executions
that exceed the public contract limits.

## 1. Program document

A program is a canonical CRE JSON value with exactly these fields:

```json
{"format":"afterimage-pulse/0.1","cells":[],"handlers":[]}
```

`cells` is an ordered list of unique `{name,type,initial}` maps. The only cell
types are `int` and `bool`; the initial value MUST have exactly that type.
Cells exist for the entire run, so `live_state_cells` is the declared cell
count.

`handlers` is a non-empty list of unique `{id,on,actions}` maps. `id` is used
for deterministic handler order. `on` MUST name the contract input topic or
timer topic. At one event, all matching handlers run in UTF-8 byte order of
their IDs; actions within one handler run in document order.

## 2. Expressions

Expressions are prefix arrays:

| Form | Type and meaning |
| --- | --- |
| `["const", value]` | CRE value; `int` and `bool` retain their scalar type |
| `["cell", name]` | current typed cell value |
| `["event", "at"]` | current event time as `int` |
| `["event", "payload"]` | current event payload |
| `add`, `sub` | two integers to integer |
| `lt`, `le` | two integers to Boolean |
| `eq` | equal-compatible values to Boolean using CRE equality |
| `and`, `or` | two Booleans to Boolean |
| `not` | one Boolean to Boolean |

The verifier MUST type-check every expression and action before running any
fixture. There is no implicit Boolean/integer conversion.

## 3. Actions

The supported action maps are:

```json
{"op":"set","cell":"deadline","value":["const",5]}
{"op":"schedule","key":"bell","topic":"pulse.timer","at":["cell","deadline"],"payload":["const",{}]}
{"op":"emit","topic":"rail.stable-bell","payload":["event","payload"]}
{"op":"when","condition":["const",true],"actions":[]}
```

`set` MUST preserve the declared cell type. `schedule` uses a non-empty static
key, the contract timer topic, an integer time not earlier than the current
event, and any CRE payload. Scheduling a key atomically invalidates its older
pending timer. Stale queue entries are ignored and execute no handler.
`emit` MUST use the contract output topic. `when` executes its nested actions
only when its Boolean condition is true. Conditional nesting is capped at
eight levels; it does not introduce a loop.

## 4. Queue and microsteps

The initial queue contains the fixture's external input events. Queue order is
the tuple:

```text
(time, phase, source EventId)
```

External inputs have phase 0 and timers have phase 1. Consequently, every
external pulse at time `t` runs before a timer due at `t`; it can replace that
timer before the timer fires. Within one phase, source EventId order is used.
This microstep rule makes a pulse exactly five ticks after its predecessor
part of the same cluster.

Timer EventIds bind the timer key, due time, payload, replacement generation,
and scheduling source EventId. Emitted outputs are observed in execution
order. Runs begin with fresh cells, queue, generations, and output trace.

## 5. One Bell exhaustive domain

For `PULSE.001`, the generated domain is every subset of times `0..11` having
zero through seven members. It has 3,302 sequences. Named fixtures add
duplicate-time sequences `(0,0)` and `(11,11)`; boundary subsets already in
the generated domain are de-duplicated. The final domain therefore has 3,304
runs and is checked in tuple lexicographic order.

A maximal cluster continues while each adjacent gap is at most five. Its only
expected output occurs at `last_pulse + 5`, on the contract output topic, with
the exact contract payload. The empty input has no output. The first mismatch
or resource failure is the stable counterexample and reports input, expected
trace, observed trace when available, and an inner error code for runtime
failures.

## 6. Limits and metrics

The public contract bounds canonical program bytes, declared state cells,
executed actions, maximum queue size, and scheduled timers. Replaced timers
still count as scheduled work and remain queue entries until discarded, so a
program cannot evade resource accounting through replacement.

After all domain cases pass, the score tuple is:

```text
(program_bytes, worst_latency, live_state_cells)
```

`program_bytes` is the canonical byte length of the program map only; the
optional invariant note is excluded. `worst_latency` is five for a valid One
Bell program under its complete domain. `live_state_cells` is the declared
cell count. Scoring is considered only after exhaustive validity succeeds.
