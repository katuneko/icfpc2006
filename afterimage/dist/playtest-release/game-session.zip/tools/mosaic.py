#!/usr/bin/env python3
"""D4 graph-certificate validation for the MOSAIC vertical-slice family."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "reference" / "python"))

import cre


TRANSFORMS = {
    "r0": lambda x, y: (x, y),
    "r90": lambda x, y: (-y, x),
    "r180": lambda x, y: (-x, -y),
    "r270": lambda x, y: (y, -x),
    "mx": lambda x, y: (-x, y),
    "mxr90": lambda x, y: (-y, -x),
    "mxr180": lambda x, y: (x, -y),
    "mxr270": lambda x, y: (y, x),
}


class MosaicError(Exception):
    def __init__(self, code: str, message: str, context: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.context = context or {}


def require(condition: bool, code: str, message: str, **context: Any) -> None:
    if not condition:
        raise MosaicError(code, message, context)


def integer(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def edge_key(a: str, b: str) -> tuple[str, str]:
    return (a, b) if a.encode("utf-8") < b.encode("utf-8") else (b, a)


def validate_global(value: Any, width: int, height: int) -> dict[str, Any]:
    require(isinstance(value, dict) and set(value) == {"vertices", "edges"}, "mosaic_graph", "global graph fields are invalid")
    expected_count = width * height
    require(isinstance(value["vertices"], list) and len(value["vertices"]) == expected_count, "mosaic_graph", "global graph has the wrong vertex count")
    vertices: dict[str, tuple[int, int]] = {}
    coordinates: set[tuple[int, int]] = set()
    for index, item in enumerate(value["vertices"]):
        require(isinstance(item, dict) and set(item) == {"id", "x", "y"}, "mosaic_graph", "global vertex fields are invalid", index=index)
        expected_id = f"v{index}"
        require(item["id"] == expected_id and integer(item["x"]) and integer(item["y"]), "mosaic_graph", "global vertex identity is not canonical", index=index)
        require((item["x"], item["y"]) == (index % width, index // width), "mosaic_graph", "global vertices must be row-major", index=index)
        vertices[item["id"]] = (item["x"], item["y"])
        coordinates.add((item["x"], item["y"]))
    require(len(coordinates) == expected_count, "mosaic_graph", "global coordinates are duplicated")
    expected_edges = width * (height - 1) + height * (width - 1)
    require(isinstance(value["edges"], list) and len(value["edges"]) == expected_edges, "mosaic_graph", "global graph has the wrong edge count")
    edges: dict[tuple[str, str], tuple[str, str]] = {}
    for index, item in enumerate(value["edges"]):
        require(isinstance(item, dict) and set(item) == {"a", "b", "material", "level"}, "mosaic_graph", "global edge fields are invalid", index=index)
        a, b = item["a"], item["b"]
        require(a in vertices and b in vertices and isinstance(item["material"], str) and isinstance(item["level"], str), "mosaic_graph", "global edge value is invalid", index=index)
        ax, ay = vertices[a]
        bx, by = vertices[b]
        require(abs(ax - bx) + abs(ay - by) == 1, "mosaic_graph", "global edge is not grid-adjacent", index=index)
        key = edge_key(a, b)
        require(key not in edges, "mosaic_graph", "global edge is duplicated", index=index)
        edges[key] = (item["material"], item["level"])
    for y in range(height):
        for x in range(width):
            here = f"v{y * width + x}"
            if x + 1 < width:
                require(edge_key(here, f"v{y * width + x + 1}") in edges, "mosaic_graph", "global horizontal edge is missing")
            if y + 1 < height:
                require(edge_key(here, f"v{(y + 1) * width + x}") in edges, "mosaic_graph", "global vertical edge is missing")
    return {"value": value, "vertices": vertices, "edges": edges}


def graph_encoding(graph: dict[str, Any], transform_name: str, width: int, height: int) -> list[list[str]]:
    transform = TRANSFORMS[transform_name]
    transformed = {vertex: transform(*coord) for vertex, coord in graph["vertices"].items()}
    min_x = min(x for x, _y in transformed.values())
    min_y = min(y for _x, y in transformed.values())
    normalized = {vertex: (x - min_x, y - min_y) for vertex, (x, y) in transformed.items()}
    require(set(normalized.values()) == {(x, y) for y in range(height) for x in range(width)}, "mosaic_graph", "transformed graph does not fill the declared grid")
    labels = {vertex: f"v{y * width + x}" for vertex, (x, y) in normalized.items()}
    encoded = []
    for (a, b), (material, level) in graph["edges"].items():
        na, nb = edge_key(labels[a], labels[b])
        encoded.append([na, nb, material, level])
    return sorted(encoded, key=lambda item: tuple(part.encode("utf-8") for part in item))


def require_canonical(graph: dict[str, Any], width: int, height: int) -> None:
    current = graph_encoding(graph, "r0", width, height)
    alternatives = [graph_encoding(graph, name, width, height) for name in TRANSFORMS]
    best = min(alternatives, key=cre.canonical_bytes)
    require(cre.same_value(current, best), "mosaic_noncanonical", "global graph orientation is not the canonical D4 representative")


def validate_fragment(value: Any) -> dict[str, Any]:
    keys = {"id", "weight", "vertices", "edges"}
    require(isinstance(value, dict) and set(value) == keys, "invalid_case", "MOSAIC fragment fields are invalid")
    require(isinstance(value["id"], str) and value["id"] and integer(value["weight"]) and value["weight"] >= 0, "invalid_case", "MOSAIC fragment identity is invalid")
    require(isinstance(value["vertices"], list) and 4 <= len(value["vertices"]) <= 6, "invalid_case", "MOSAIC fragment vertex count is invalid")
    vertices: dict[str, tuple[int, int]] = {}
    for item in value["vertices"]:
        require(isinstance(item, dict) and set(item) == {"name", "x", "y"}, "invalid_case", "MOSAIC local vertex fields are invalid")
        require(isinstance(item["name"], str) and item["name"] not in vertices and integer(item["x"]) and integer(item["y"]), "invalid_case", "MOSAIC local vertex is invalid")
        vertices[item["name"]] = (item["x"], item["y"])
    require(len(set(vertices.values())) == len(vertices), "invalid_case", "MOSAIC local coordinates are duplicated")
    require(isinstance(value["edges"], list), "invalid_case", "MOSAIC fragment edges must be a list")
    edges: dict[tuple[str, str], tuple[str, str]] = {}
    for item in value["edges"]:
        require(isinstance(item, dict) and set(item) == {"a", "b", "material", "level"}, "invalid_case", "MOSAIC local edge fields are invalid")
        require(item["a"] in vertices and item["b"] in vertices and isinstance(item["material"], str) and isinstance(item["level"], str), "invalid_case", "MOSAIC local edge is invalid")
        key = edge_key(item["a"], item["b"])
        require(key not in edges, "invalid_case", "MOSAIC local edge is duplicated")
        edges[key] = (item["material"], item["level"])
    return {"id": value["id"], "weight": value["weight"], "vertices": vertices, "edges": edges}


def embeddings(fragment: dict[str, Any], graph: dict[str, Any], width: int, height: int, only_transform: str | None = None) -> list[tuple[str, dict[str, str]]]:
    result = []
    names = [only_transform] if only_transform else list(TRANSFORMS)
    coordinate_to_id = {coord: vertex for vertex, coord in graph["vertices"].items()}
    for transform_name in names:
        transform = TRANSFORMS[transform_name]
        transformed = {name: transform(*coord) for name, coord in fragment["vertices"].items()}
        for tx in range(-3, width + 3):
            for ty in range(-3, height + 3):
                mapping = {name: coordinate_to_id.get((x + tx, y + ty)) for name, (x, y) in transformed.items()}
                if any(vertex is None for vertex in mapping.values()) or len(set(mapping.values())) != len(mapping):
                    continue
                if all(graph["edges"].get(edge_key(mapping[a], mapping[b])) == attributes for (a, b), attributes in fragment["edges"].items()):
                    result.append((transform_name, mapping))
    return result


def validate_answer(fragments_value: list[Any], answer: Any, contract: Any) -> dict[str, int]:
    require(isinstance(contract, dict) and set(contract) == {"width", "height"}, "invalid_score", "MOSAIC contract fields are invalid")
    width, height = contract["width"], contract["height"]
    require(integer(width) and integer(height) and width > 0 and height > 0, "invalid_score", "MOSAIC dimensions are invalid")
    require(isinstance(answer, dict) and set(answer) == {"global", "used", "unused"}, "mosaic_schema", "MOSAIC answer fields are invalid")
    graph = validate_global(answer["global"], width, height)
    require_canonical(graph, width, height)
    fragments = [validate_fragment(value) for value in fragments_value]
    by_id = {fragment["id"]: fragment for fragment in fragments}
    require(len(by_id) == len(fragments), "invalid_case", "MOSAIC fragment IDs are duplicated")
    require(isinstance(answer["used"], list) and isinstance(answer["unused"], list), "mosaic_schema", "MOSAIC classification must use lists")
    used_ids: set[str] = set()
    covered_vertices: set[str] = set()
    covered_edges: set[tuple[str, str]] = set()
    for index, item in enumerate(answer["used"]):
        require(isinstance(item, dict) and set(item) == {"fragment", "transform", "mapping"}, "mosaic_mapping", "used-fragment fields are invalid", index=index)
        fragment_id = item["fragment"]
        require(fragment_id in by_id and fragment_id not in used_ids and item["transform"] in TRANSFORMS, "mosaic_mapping", "used-fragment identity is invalid", index=index)
        fragment = by_id[fragment_id]
        require(isinstance(item["mapping"], list), "mosaic_mapping", "fragment mapping must be a list", index=index)
        mapping: dict[str, str] = {}
        for pair in item["mapping"]:
            require(isinstance(pair, dict) and set(pair) == {"local", "global"} and pair["local"] in fragment["vertices"] and pair["global"] in graph["vertices"] and pair["local"] not in mapping, "mosaic_mapping", "fragment mapping entry is invalid", fragment=fragment_id)
            mapping[pair["local"]] = pair["global"]
        require(set(mapping) == set(fragment["vertices"]) and len(set(mapping.values())) == len(mapping), "mosaic_mapping", "fragment mapping is incomplete or non-injective", fragment=fragment_id)
        valid = any(cre.same_value(candidate, mapping) for _name, candidate in embeddings(fragment, graph, width, height, item["transform"]))
        require(valid, "mosaic_mapping", "fragment transform or edge correspondence is invalid", fragment=fragment_id)
        used_ids.add(fragment_id)
        covered_vertices.update(mapping.values())
        covered_edges.update(edge_key(mapping[a], mapping[b]) for a, b in fragment["edges"])
    unused_ids: set[str] = set()
    for index, item in enumerate(answer["unused"]):
        require(isinstance(item, dict) and set(item) == {"fragment", "reason"}, "mosaic_classification", "unused-fragment fields are invalid", index=index)
        fragment_id = item["fragment"]
        require(fragment_id in by_id and fragment_id not in unused_ids and item["reason"] == "invariant_conflict", "mosaic_classification", "unused-fragment classification is invalid", index=index)
        require(not embeddings(by_id[fragment_id], graph, width, height), "mosaic_classification", "unused fragment still embeds in submitted graph", fragment=fragment_id)
        unused_ids.add(fragment_id)
    require(not used_ids & unused_ids and used_ids | unused_ids == set(by_id), "mosaic_classification", "every fragment must be classified exactly once")
    require(covered_vertices == set(graph["vertices"]) and covered_edges == set(graph["edges"]), "mosaic_coverage", "used fragments do not cover the complete global graph")
    return {
        "unexplained_weight": sum(by_id[fragment_id]["weight"] for fragment_id in unused_ids),
        "graph_size": len(graph["vertices"]) + len(graph["edges"]),
        "certificate_units": (len(cre.canonical_bytes(answer["used"])) + 63) // 64,
    }
