#!/usr/bin/env python3
"""Bounded deterministic runtime and exhaustive checker for PULSE 0.1."""

from __future__ import annotations

import argparse
import heapq
import itertools
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "reference" / "python"))

import cre


class PulseError(Exception):
    def __init__(self, code: str, message: str, context: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.context = context or {}


def require(condition: bool, code: str, message: str, **context: Any) -> None:
    if not condition:
        raise PulseError(code, message, context)


def is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def value_type(value: Any) -> str:
    if isinstance(value, bool):
        return "bool"
    if is_int(value):
        return "int"
    return "value"


def validate_contract(value: Any) -> dict[str, Any]:
    keys = {
        "input_topic", "timer_topic", "output_topic", "output_payload", "quiet_ticks",
        "horizon", "max_pulses", "named_fixtures", "limits",
    }
    require(isinstance(value, dict) and set(value) == keys, "invalid_pulse_contract", "PULSE contract fields are invalid")
    for name in ("input_topic", "timer_topic", "output_topic"):
        require(isinstance(value[name], str) and value[name], "invalid_pulse_contract", "PULSE topic is invalid", field=name)
    for name in ("quiet_ticks", "horizon", "max_pulses"):
        require(is_int(value[name]) and value[name] >= 0, "invalid_pulse_contract", "PULSE domain integer is invalid", field=name)
    require(value["quiet_ticks"] > 0 and value["horizon"] > 0, "invalid_pulse_contract", "PULSE horizon and quiet period must be positive")
    fixtures = value["named_fixtures"]
    require(isinstance(fixtures, list), "invalid_pulse_contract", "PULSE named fixtures must be a list")
    for index, fixture in enumerate(fixtures):
        require(isinstance(fixture, list) and all(is_int(item) and item >= 0 for item in fixture), "invalid_pulse_contract", "PULSE fixture is invalid", index=index)
        require(fixture == sorted(fixture), "invalid_pulse_contract", "PULSE fixture times must be sorted", index=index)
    limits = value["limits"]
    limit_keys = {"max_program_bytes", "max_state_cells", "max_steps", "max_queue", "max_scheduled_events"}
    require(isinstance(limits, dict) and set(limits) == limit_keys, "invalid_pulse_contract", "PULSE limit fields are invalid")
    require(all(is_int(item) and item > 0 for item in limits.values()), "invalid_pulse_contract", "PULSE limits must be positive integers")
    try:
        cre.canonical_bytes(value["output_payload"])
    except cre.CREError as exc:
        raise PulseError("invalid_pulse_contract", "PULSE output payload is not a CRE value") from exc
    return value


def compile_program(value: Any, contract: dict[str, Any]) -> dict[str, Any]:
    require(isinstance(value, dict) and set(value) == {"format", "cells", "handlers"}, "invalid_pulse_program", "PULSE program fields are invalid")
    require(value["format"] == "afterimage-pulse/0.1", "invalid_pulse_program", "PULSE program format is unsupported")
    program_bytes = len(cre.canonical_bytes(value))
    require(program_bytes <= contract["limits"]["max_program_bytes"], "pulse_limit", "PULSE program exceeds byte limit", observed=program_bytes)
    require(isinstance(value["cells"], list), "invalid_pulse_program", "PULSE cells must be a list")
    require(len(value["cells"]) <= contract["limits"]["max_state_cells"], "pulse_limit", "PULSE program exceeds state-cell limit")
    cell_types: dict[str, str] = {}
    initial: dict[str, Any] = {}
    for index, cell in enumerate(value["cells"]):
        require(isinstance(cell, dict) and set(cell) == {"name", "type", "initial"}, "invalid_pulse_program", "PULSE cell fields are invalid", index=index)
        name, kind = cell["name"], cell["type"]
        require(isinstance(name, str) and name and name not in cell_types, "invalid_pulse_program", "PULSE cell name is invalid", index=index)
        require(kind in {"int", "bool"} and value_type(cell["initial"]) == kind, "invalid_pulse_program", "PULSE cell type or initial value is invalid", cell=name)
        cell_types[name] = kind
        initial[name] = cell["initial"]

    def expression_type(expr: Any, path: str) -> str:
        require(isinstance(expr, list) and expr and isinstance(expr[0], str), "invalid_pulse_program", "PULSE expression is invalid", path=path)
        op = expr[0]
        if op == "const":
            require(len(expr) == 2, "invalid_pulse_program", "const expression arity is invalid", path=path)
            try:
                cre.canonical_bytes(expr[1])
            except cre.CREError as exc:
                raise PulseError("invalid_pulse_program", "const expression is not a CRE value", {"path": path}) from exc
            return value_type(expr[1])
        if op == "cell":
            require(len(expr) == 2 and expr[1] in cell_types, "invalid_pulse_program", "cell expression names an unknown cell", path=path)
            return cell_types[expr[1]]
        if op == "event":
            require(len(expr) == 2 and expr[1] in {"at", "payload"}, "invalid_pulse_program", "event expression selector is invalid", path=path)
            return "int" if expr[1] == "at" else "value"
        binary = {"add": ("int", "int"), "sub": ("int", "int"), "lt": ("int", "bool"), "le": ("int", "bool"), "and": ("bool", "bool"), "or": ("bool", "bool")}
        if op in binary:
            argument_type, result_type = binary[op]
            require(len(expr) == 3, "invalid_pulse_program", "binary expression arity is invalid", path=path)
            require(expression_type(expr[1], f"{path}/1") == argument_type and expression_type(expr[2], f"{path}/2") == argument_type, "invalid_pulse_program", "binary expression types are invalid", path=path)
            return result_type
        if op == "eq":
            require(len(expr) == 3, "invalid_pulse_program", "eq expression arity is invalid", path=path)
            left, right = expression_type(expr[1], f"{path}/1"), expression_type(expr[2], f"{path}/2")
            require(left == right or "value" in {left, right}, "invalid_pulse_program", "eq expression types are invalid", path=path)
            return "bool"
        if op == "not":
            require(len(expr) == 2 and expression_type(expr[1], f"{path}/1") == "bool", "invalid_pulse_program", "not expression is invalid", path=path)
            return "bool"
        raise PulseError("invalid_pulse_program", "PULSE expression operator is unsupported", {"path": path, "operator": op})

    def validate_actions(actions: Any, path: str, depth: int = 0) -> None:
        require(isinstance(actions, list), "invalid_pulse_program", "PULSE actions must be a list", path=path)
        require(depth <= 8, "invalid_pulse_program", "PULSE conditional nesting is too deep", path=path)
        for index, action in enumerate(actions):
            here = f"{path}/{index}"
            require(isinstance(action, dict) and isinstance(action.get("op"), str), "invalid_pulse_program", "PULSE action is invalid", path=here)
            op = action["op"]
            if op == "set":
                require(set(action) == {"op", "cell", "value"} and action["cell"] in cell_types, "invalid_pulse_program", "set action fields are invalid", path=here)
                require(expression_type(action["value"], f"{here}/value") == cell_types[action["cell"]], "invalid_pulse_program", "set action type is invalid", path=here)
            elif op == "schedule":
                require(set(action) == {"op", "key", "topic", "at", "payload"}, "invalid_pulse_program", "schedule action fields are invalid", path=here)
                require(isinstance(action["key"], str) and action["key"] and action["topic"] == contract["timer_topic"], "invalid_pulse_program", "schedule key or topic is invalid", path=here)
                require(expression_type(action["at"], f"{here}/at") == "int", "invalid_pulse_program", "schedule time must be Int", path=here)
                expression_type(action["payload"], f"{here}/payload")
            elif op == "emit":
                require(set(action) == {"op", "topic", "payload"} and action["topic"] == contract["output_topic"], "invalid_pulse_program", "emit action fields are invalid", path=here)
                expression_type(action["payload"], f"{here}/payload")
            elif op == "when":
                require(set(action) == {"op", "condition", "actions"}, "invalid_pulse_program", "when action fields are invalid", path=here)
                require(expression_type(action["condition"], f"{here}/condition") == "bool", "invalid_pulse_program", "when condition must be Bool", path=here)
                validate_actions(action["actions"], f"{here}/actions", depth + 1)
            else:
                raise PulseError("invalid_pulse_program", "PULSE action operator is unsupported", {"path": here, "operator": op})

    handlers = value["handlers"]
    require(isinstance(handlers, list) and handlers, "invalid_pulse_program", "PULSE handlers must be a non-empty list")
    handler_ids: set[str] = set()
    allowed_topics = {contract["input_topic"], contract["timer_topic"]}
    for index, handler in enumerate(handlers):
        require(isinstance(handler, dict) and set(handler) == {"id", "on", "actions"}, "invalid_pulse_program", "PULSE handler fields are invalid", index=index)
        require(isinstance(handler["id"], str) and handler["id"] and handler["id"] not in handler_ids, "invalid_pulse_program", "PULSE handler ID is invalid", index=index)
        require(handler["on"] in allowed_topics, "invalid_pulse_program", "PULSE handler topic is invalid", index=index)
        handler_ids.add(handler["id"])
        validate_actions(handler["actions"], f"/handlers/{index}/actions")
    return {"value": value, "initial": initial, "cell_types": cell_types, "program_bytes": program_bytes}


def evaluate(expr: list[Any], state: dict[str, Any], event: dict[str, Any]) -> Any:
    op = expr[0]
    if op == "const":
        return expr[1]
    if op == "cell":
        return state[expr[1]]
    if op == "event":
        return event[expr[1]]
    if op == "not":
        return not evaluate(expr[1], state, event)
    left = evaluate(expr[1], state, event)
    right = evaluate(expr[2], state, event)
    return {
        "add": lambda: left + right,
        "sub": lambda: left - right,
        "eq": lambda: cre.same_value(left, right),
        "lt": lambda: left < right,
        "le": lambda: left <= right,
        "and": lambda: left and right,
        "or": lambda: left or right,
    }[op]()


@dataclass
class RunResult:
    outputs: list[dict[str, Any]]
    steps: int
    scheduled: int
    max_queue: int


def run(compiled: dict[str, Any], contract: dict[str, Any], pulse_times: Iterable[int]) -> RunResult:
    program = compiled["value"]
    state = dict(compiled["initial"])
    queue: list[tuple[int, int, bytes, int, dict[str, Any]]] = []
    serial = 0
    for sequence, at in enumerate(pulse_times):
        event_id = cre.digest_id("afterimage/pulse-input/1", cre.canonical_bytes([sequence, at]))
        event = {"id": event_id, "at": at, "topic": contract["input_topic"], "payload": {"sequence": sequence}}
        heapq.heappush(queue, (at, 0, cre.parse_id(event_id), serial, event))
        serial += 1
    active_timers: dict[str, int] = {}
    timer_generation = 0
    scheduled = 0
    steps = 0
    max_queue = len(queue)
    outputs: list[dict[str, Any]] = []
    handlers = sorted(program["handlers"], key=lambda item: item["id"].encode("utf-8"))
    limits = contract["limits"]

    def execute(actions: list[dict[str, Any]], event: dict[str, Any]) -> None:
        nonlocal serial, timer_generation, scheduled, steps, max_queue
        for action in actions:
            steps += 1
            require(steps <= limits["max_steps"], "pulse_limit", "PULSE execution exceeds step limit")
            op = action["op"]
            if op == "set":
                state[action["cell"]] = evaluate(action["value"], state, event)
            elif op == "schedule":
                at = evaluate(action["at"], state, event)
                require(at >= event["at"], "pulse_runtime", "PULSE timer was scheduled in the past")
                payload = evaluate(action["payload"], state, event)
                timer_generation += 1
                scheduled += 1
                require(scheduled <= limits["max_scheduled_events"], "pulse_limit", "PULSE execution exceeds scheduled-event limit")
                key = action["key"]
                active_timers[key] = timer_generation
                timer_id = cre.digest_id("afterimage/pulse-timer/1", cre.canonical_bytes([key, at, payload, timer_generation, event["id"]]))
                timer = {"id": timer_id, "at": at, "topic": action["topic"], "payload": payload, "timer_key": key, "timer_generation": timer_generation}
                heapq.heappush(queue, (at, 1, cre.parse_id(timer_id), serial, timer))
                serial += 1
                max_queue = max(max_queue, len(queue))
                require(max_queue <= limits["max_queue"], "pulse_limit", "PULSE execution exceeds queue limit")
            elif op == "emit":
                outputs.append({"at": event["at"], "topic": action["topic"], "payload": evaluate(action["payload"], state, event)})
            elif op == "when" and evaluate(action["condition"], state, event):
                execute(action["actions"], event)

    while queue:
        _at, _phase, _identity, _serial, event = heapq.heappop(queue)
        if "timer_key" in event:
            if active_timers.get(event["timer_key"]) != event["timer_generation"]:
                continue
            del active_timers[event["timer_key"]]
        for handler in handlers:
            if handler["on"] == event["topic"]:
                execute(handler["actions"], event)
    return RunResult(outputs=outputs, steps=steps, scheduled=scheduled, max_queue=max_queue)


def domain(contract: dict[str, Any]) -> list[tuple[int, ...]]:
    generated = itertools.chain.from_iterable(itertools.combinations(range(contract["horizon"]), length) for length in range(contract["max_pulses"] + 1))
    return sorted(set(generated) | {tuple(item) for item in contract["named_fixtures"]})


def expected_times(pulses: tuple[int, ...], quiet_ticks: int) -> list[int]:
    if not pulses:
        return []
    result: list[int] = []
    last = pulses[0]
    for at in pulses[1:]:
        if at - last > quiet_ticks:
            result.append(last + quiet_ticks)
        last = at
    result.append(last + quiet_ticks)
    return result


def verify_program(program: Any, contract_value: Any) -> dict[str, int]:
    contract = validate_contract(contract_value)
    compiled = compile_program(program, contract)
    for pulses in domain(contract):
        expected = [{"at": at, "topic": contract["output_topic"], "payload": contract["output_payload"]} for at in expected_times(pulses, contract["quiet_ticks"])]
        try:
            observed = run(compiled, contract, pulses).outputs
        except PulseError as exc:
            raise PulseError("pulse_counterexample", "PULSE program failed on exhaustive domain", {"input": list(pulses), "expected": expected, "observed": [], "inner_code": exc.code}) from exc
        if not cre.same_value(observed, expected):
            raise PulseError("pulse_counterexample", "PULSE program disagrees with exhaustive domain", {"input": list(pulses), "expected": expected, "observed": observed})
    return {
        "program_bytes": compiled["program_bytes"],
        "worst_latency": contract["quiet_ticks"],
        "live_state_cells": len(compiled["initial"]),
        "domain_cases": len(domain(contract)),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "PULSE 0.1 runtime library. Player submissions are checked through "
            "player.py verify; this command documents the standalone helper."
        )
    )
    parser.parse_args(argv)
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
