#!/usr/bin/env python3
"""Authoritative offline witness verifier for Afterimage 0.1."""

from __future__ import annotations

import argparse
import copy
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT / "reference" / "python"))

import afterimage_kit as kit  # noqa: E402
import cre  # noqa: E402
import pulse as pulse_runtime  # noqa: E402
import mosaic as mosaic_runtime  # noqa: E402
import lens as lens_runtime  # noqa: E402
import covenant as covenant_runtime  # noqa: E402
import paradox as paradox_runtime  # noqa: E402


MAX_WITNESS_BYTES = 1024 * 1024
CASE_KEYS = {
    "id",
    "family",
    "title",
    "points",
    "requires",
    "input_branch",
    "world",
    "projection",
    "answer_schema",
    "validator",
    "intervention_policy",
    "score",
    "limits",
}
WITNESS_REQUIRED = {
    "format",
    "semantics",
    "bundle",
    "case",
    "parent_branch",
    "intervention",
    "answer",
}
WITNESS_OPTIONAL = {"claimed", "meta", "history"}
DIAGNOSTIC_KEYS = {"code", "message", "context"}
MAX_HISTORY_STEPS = 32


class VerificationError(Exception):
    def __init__(self, code: str, message: str, context: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.context = context or {}

    def diagnostic(self) -> dict[str, Any]:
        return {"code": self.code, "message": self.message, "context": self.context}


def fail(code: str, message: str, **context: Any) -> None:
    raise VerificationError(code, message, context)


def require_map(value: Any, keys: set[str], location: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != keys:
        fail("invalid_schema", "object has wrong fields", path=location, expected=sorted(keys))
    return value


def checked_nonnegative(value: Any, location: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        fail("invalid_schema", "value must be a non-negative Int", path=location)
    return value


def validate_case_descriptor(value: Any, world: kit.ValidatedBundle) -> dict[str, Any]:
    case = require_map(value, CASE_KEYS, "cases/index.json#/case")
    for key in ("id", "family", "title", "world", "projection", "answer_schema", "validator", "intervention_policy", "score"):
        if not isinstance(case[key], str) or not case[key]:
            fail("invalid_case", "case Text field must be non-empty", field=key)
    if case["family"] not in {"ORIENT", "CASCADE", "MERGE", "PULSE", "MOSAIC", "LENS", "COVENANT", "PARADOX"}:
        fail("invalid_case", "unknown case family", family=case["family"])
    if isinstance(case["points"], bool) or not isinstance(case["points"], int) or case["points"] <= 0:
        fail("invalid_case", "case points must be positive")
    if case["input_branch"] != "root":
        if not case["input_branch"].startswith("history:") or not case["input_branch"][len("history:"):]:
            fail("invalid_case", "input_branch must be root or history:<case-id>")
    if not isinstance(case["requires"], dict) or not isinstance(case["limits"], dict):
        fail("invalid_case", "case requires and limits must be maps")
    try:
        logical = kit.resolve_logical_world(world, case["world"])
    except kit.KitError as exc:
        raise VerificationError("invalid_case", exc.message, {"field": "world", **exc.context}) from exc
    projection_ids = {entry["id"] for entry in logical.projection_index["projections"]}
    if case["projection"] not in projection_ids:
        fail("invalid_case", "case references an unknown projection", projection=case["projection"])
    for key in ("answer_schema", "validator", "intervention_policy", "score"):
        path = kit.canonical_path(case[key])
        if path not in world.json_values:
            fail("invalid_case", "case references a missing canonical JSON file", field=key, path=path)
    allowed_limits = {"max_witness_bytes", "replay", "validator"}
    if set(case["limits"]) - allowed_limits:
        fail("invalid_case", "case limits contain unknown keys")
    if "max_witness_bytes" in case["limits"]:
        limit = checked_nonnegative(case["limits"]["max_witness_bytes"], "case.limits.max_witness_bytes")
        if limit <= 0 or limit > MAX_WITNESS_BYTES:
            fail("invalid_case", "max_witness_bytes is outside verifier bounds")
    for key in ("replay", "validator"):
        if key in case["limits"]:
            try:
                cre.Counters.create(case["limits"][key])
            except cre.CREError as exc:
                raise VerificationError("invalid_case", exc.message, {"field": f"limits.{key}", **exc.context}) from exc
    return case


def requirements_hold(expr: Any, facts: set[str]) -> bool:
    if not isinstance(expr, dict) or not expr or set(expr) - {"all", "any", "at_least"}:
        fail("invalid_case", "unlock expression is invalid")
    if "all" in expr:
        if not isinstance(expr["all"], list) or not all(isinstance(item, str) for item in expr["all"]):
            fail("invalid_case", "unlock all must be a Text list")
        if not all(item in facts for item in expr["all"]):
            return False
    if "any" in expr:
        if not isinstance(expr["any"], list) or not expr["any"] or not all(isinstance(item, str) for item in expr["any"]):
            fail("invalid_case", "unlock any must be a non-empty Text list")
        if not any(item in facts for item in expr["any"]):
            return False
    if "at_least" in expr:
        spec = require_map(expr["at_least"], {"count", "of"}, "case.requires.at_least")
        count = checked_nonnegative(spec["count"], "case.requires.at_least.count")
        if count <= 0 or not isinstance(spec["of"], list) or len(set(spec["of"])) != len(spec["of"]):
            fail("invalid_case", "unlock at_least is invalid")
        if not all(isinstance(item, str) for item in spec["of"]) or count > len(spec["of"]):
            fail("invalid_case", "unlock at_least options are invalid")
        if sum(item in facts for item in spec["of"]) < count:
            return False
    return True


def schema_error(path: str, message: str, **context: Any) -> VerificationError:
    return VerificationError("answer_schema", message, {"path": path, **context})


def validate_schema_node(schema_value: Any, value: Any, path: str = "") -> None:
    if not isinstance(schema_value, dict) or not isinstance(schema_value.get("type"), str):
        fail("invalid_answer_schema", "schema node requires a type", path=path)
    schema = schema_value
    kind = schema["type"]
    common = {"type", "const", "enum"}
    allowed_by_type = {
        "null": common,
        "bool": common,
        "int": common | {"minimum", "maximum"},
        "text": common | {"min_length", "max_length"},
        "bytes": common | {"min_length", "max_length"},
        "id": common,
        "list": common | {"items", "min_items", "max_items"},
        "map": common | {"required", "properties", "additional", "min_properties", "max_properties"},
    }
    if kind not in allowed_by_type or set(schema) - allowed_by_type[kind]:
        fail("invalid_answer_schema", "schema node has unknown type or fields", path=path, type=kind)
    if "const" in schema and not cre.same_value(value, schema["const"]):
        raise schema_error(path, "answer does not equal required constant")
    if "enum" in schema:
        if not isinstance(schema["enum"], list) or not schema["enum"]:
            fail("invalid_answer_schema", "enum must be a non-empty list", path=path)
        if not any(cre.same_value(value, choice) for choice in schema["enum"]):
            raise schema_error(path, "answer value is outside enum")

    type_ok = {
        "null": value is None,
        "bool": isinstance(value, bool),
        "int": isinstance(value, int) and not isinstance(value, bool),
        "text": isinstance(value, str),
        "bytes": isinstance(value, bytes),
        "id": isinstance(value, str),
        "list": isinstance(value, list),
        "map": isinstance(value, dict),
    }[kind]
    if not type_ok:
        raise schema_error(path, f"answer value must have type {kind}")
    if kind == "id":
        try:
            cre.parse_id(value, "answer ID")
        except cre.CREError as exc:
            raise schema_error(path, exc.message) from exc
    if kind == "int":
        for key, relation in (("minimum", lambda a, b: a >= b), ("maximum", lambda a, b: a <= b)):
            if key in schema:
                bound = schema[key]
                if isinstance(bound, bool) or not isinstance(bound, int):
                    fail("invalid_answer_schema", f"{key} must be Int", path=path)
                if not relation(value, bound):
                    raise schema_error(path, f"answer integer violates {key}", bound=bound)
    if kind in {"text", "bytes"}:
        length = len(value)
        for key, relation in (("min_length", lambda a, b: a >= b), ("max_length", lambda a, b: a <= b)):
            if key in schema:
                bound = checked_nonnegative(schema[key], f"schema{path}.{key}")
                if not relation(length, bound):
                    raise schema_error(path, f"answer length violates {key}", bound=bound)
    if kind == "list":
        if "items" not in schema:
            fail("invalid_answer_schema", "list schema requires items", path=path)
        for key, relation in (("min_items", lambda a, b: a >= b), ("max_items", lambda a, b: a <= b)):
            if key in schema:
                bound = checked_nonnegative(schema[key], f"schema{path}.{key}")
                if not relation(len(value), bound):
                    raise schema_error(path, f"answer list violates {key}", bound=bound)
        for index, item in enumerate(value):
            validate_schema_node(schema["items"], item, f"{path}/{index}")
    if kind == "map":
        required = schema.get("required", [])
        properties = schema.get("properties", {})
        additional = schema.get("additional", False)
        if not isinstance(required, list) or len(set(required)) != len(required) or not all(isinstance(item, str) for item in required):
            fail("invalid_answer_schema", "map required must be a unique Text list", path=path)
        if not isinstance(properties, dict) or not isinstance(additional, bool):
            fail("invalid_answer_schema", "map properties/additional are invalid", path=path)
        missing = [key for key in required if key not in value]
        if missing:
            raise schema_error(path, "answer map lacks required properties", missing=missing)
        unknown = sorted(set(value) - set(properties))
        if unknown and not additional:
            raise schema_error(path, "answer map has additional properties", additional=unknown)
        for key, item in value.items():
            if key in properties:
                escaped = key.replace("~", "~0").replace("/", "~1")
                validate_schema_node(properties[key], item, f"{path}/{escaped}")
        for key, relation in (("min_properties", lambda a, b: a >= b), ("max_properties", lambda a, b: a <= b)):
            if key in schema:
                bound = checked_nonnegative(schema[key], f"schema{path}.{key}")
                if not relation(len(value), bound):
                    raise schema_error(path, f"answer map violates {key}", bound=bound)


def validate_answer_schema(document: Any, answer: Any) -> dict[str, Any] | None:
    if not isinstance(document, dict) or set(document) not in ({"format", "schema"}, {"format", "schema", "embedded_witness"}):
        fail("invalid_answer_schema", "answer schema document has wrong fields")
    schema_document = document
    if schema_document["format"] != "afterimage-answer-schema/0.1":
        fail("invalid_answer_schema", "answer schema format is unsupported")
    validate_schema_node(schema_document["schema"], answer)
    embedded = schema_document.get("embedded_witness")
    if embedded is None:
        return None
    embedded = require_map(embedded, {"pointer", "allowed_cases", "require_fact"}, "answer schema embedded_witness")
    if not isinstance(embedded["pointer"], str) or not embedded["pointer"].startswith("/"):
        fail("invalid_answer_schema", "embedded witness pointer must be a non-root JSON Pointer")
    if (
        not isinstance(embedded["allowed_cases"], list)
        or not embedded["allowed_cases"]
        or len(set(embedded["allowed_cases"])) != len(embedded["allowed_cases"])
        or not all(isinstance(item, str) and item for item in embedded["allowed_cases"])
        or not isinstance(embedded["require_fact"], bool)
    ):
        fail("invalid_answer_schema", "embedded witness policy is invalid")
    return embedded


@dataclass
class PolicyResult:
    operations: list[dict[str, Any]]
    weight: int


def validate_intervention(
    policy_value: Any,
    intervention: Any,
    *,
    witness_bundle: str,
    witness_case: str,
    parent_branch: str,
    base_events: list[dict[str, Any]],
    known_events: dict[str, dict[str, Any]] | None = None,
) -> PolicyResult:
    policy = require_map(
        policy_value,
        {"format", "required", "allowed_kinds", "max_operations", "weights", "topics", "pointers", "retime"},
        "intervention policy",
    )
    if policy["format"] != "afterimage-intervention-policy/0.1":
        fail("invalid_policy", "intervention policy format is unsupported")
    if not isinstance(policy["required"], bool):
        fail("invalid_policy", "policy required must be Bool")
    if not isinstance(policy["allowed_kinds"], list) or len(set(policy["allowed_kinds"])) != len(policy["allowed_kinds"]):
        fail("invalid_policy", "allowed_kinds must be a unique list")
    known_kinds = {"suppress", "replace", "retime", "inject"}
    if any(kind not in known_kinds for kind in policy["allowed_kinds"]):
        fail("invalid_policy", "allowed_kinds contains an unknown operation")
    max_operations = checked_nonnegative(policy["max_operations"], "policy.max_operations")
    if not isinstance(policy["weights"], dict) or set(policy["weights"]) != set(policy["allowed_kinds"]):
        fail("invalid_policy", "weights must exactly cover allowed_kinds")
    weights = {kind: checked_nonnegative(value, f"policy.weights.{kind}") for kind, value in policy["weights"].items()}
    if not isinstance(policy["topics"], list) or len(set(policy["topics"])) != len(policy["topics"]) or not all(isinstance(item, str) for item in policy["topics"]):
        fail("invalid_policy", "policy topics must be a unique Text list")
    if not isinstance(policy["pointers"], list) or len(set(policy["pointers"])) != len(policy["pointers"]) or not all(isinstance(item, str) for item in policy["pointers"]):
        fail("invalid_policy", "policy pointers must be a unique Text list")
    retime = require_map(policy["retime"], {"minimum", "maximum"}, "policy.retime")
    minimum = cre.checked_i64(retime["minimum"], "policy.retime.minimum")
    maximum = cre.checked_i64(retime["maximum"], "policy.retime.maximum")
    if minimum > maximum:
        fail("invalid_policy", "retime minimum exceeds maximum")

    if intervention is None:
        if policy["required"]:
            raise VerificationError("intervention_required", "case requires an intervention envelope")
        operations: list[dict[str, Any]] = []
    else:
        if not policy["required"] and max_operations == 0:
            raise VerificationError("unexpected_intervention", "non-branch case requires intervention to be null")
        envelope = require_map(
            intervention,
            {"format", "bundle", "parent_branch", "case", "operations"},
            "witness.intervention",
        )
        if envelope["format"] != "afterimage-intervention/0.1":
            raise VerificationError("invalid_intervention", "intervention format is unsupported")
        if envelope["bundle"] != witness_bundle or envelope["case"] != witness_case or envelope["parent_branch"] != parent_branch:
            raise VerificationError("invalid_intervention", "intervention envelope does not match witness")
        if not isinstance(envelope["operations"], list):
            raise VerificationError("invalid_intervention", "intervention operations must be a list")
        try:
            operations = cre.canonical_operations(envelope["operations"])
        except cre.CREError as exc:
            raise VerificationError(exc.code, exc.message, exc.context) from exc
    if len(operations) > max_operations:
        raise VerificationError("policy_violation", "operation count exceeds policy")
    if policy["required"] and not operations:
        raise VerificationError("intervention_required", "case requires at least one intervention operation")
    topics = set(policy["topics"])
    pointers = set(policy["pointers"])
    base_by_id = {event["id"]: event for event in base_events}
    total_weight = 0
    for operation in operations:
        kind = operation["kind"]
        if kind not in policy["allowed_kinds"]:
            raise VerificationError("policy_violation", "operation kind is forbidden", {"kind": kind})
        total_weight += weights[kind]
        if kind == "inject":
            if operation["topic"] not in topics:
                raise VerificationError("policy_violation", "injected topic is forbidden", {"topic": operation["topic"]})
        else:
            target = base_by_id.get(operation["event"])
            if target is None:
                known = (known_events or {}).get(operation["event"])
                if known is not None and known["origin"]["kind"] == "derived":
                    base_ids = set(base_by_id)
                    ancestors: set[str] = set()
                    pending = list(known["parents"])
                    visited: set[str] = set()
                    while pending:
                        event_id = pending.pop()
                        if event_id in visited:
                            continue
                        visited.add(event_id)
                        if event_id in base_ids:
                            ancestors.add(event_id)
                            continue
                        ancestor = (known_events or {}).get(event_id)
                        if ancestor is not None:
                            pending.extend(ancestor["parents"])
                    raise VerificationError(
                        "derived_event_not_intervenable",
                        "derived events must be changed through active base ancestors",
                        {
                            "event": operation["event"],
                            "base_ancestors": sorted(ancestors, key=cre.parse_id),
                        },
                    )
                raise VerificationError("policy_violation", "operation target is not a base event")
            if target["topic"] not in topics:
                raise VerificationError("policy_violation", "target topic is forbidden", {"topic": target["topic"]})
        if kind == "replace" and operation["pointer"] not in pointers:
            raise VerificationError("policy_violation", "replacement pointer is forbidden", {"pointer": operation["pointer"]})
        if kind == "retime" and not minimum <= operation["at"] <= maximum:
            raise VerificationError("policy_violation", "retime value is outside policy bounds")
    return PolicyResult(operations=operations, weight=total_weight)


@dataclass
class ReplayState:
    branch: str
    projection: str
    trace: str
    records: list[Any]
    counters: dict[str, int]
    events: dict[str, dict[str, Any]]
    trace_items: list[dict[str, Any]]


@dataclass
class ReplayResult:
    branch: str
    projection: str
    trace: str
    records: list[Any]
    counters: dict[str, int]
    events: dict[str, dict[str, Any]]
    trace_items: list[dict[str, Any]]
    baseline: ReplayState
    changed_event_ids: list[str]


def evaluate_case_state(
    world: kit.ValidatedBundle,
    case: dict[str, Any],
    base_events: list[dict[str, Any]],
    branch: str,
) -> ReplayState:
    logical = kit.resolve_logical_world(world, case["world"])
    projection_entry = next(
        entry for entry in logical.projection_index["projections"]
        if entry["id"] == case["projection"]
    )
    try:
        events, trace, counters = cre.evaluate_world(
            logical.program,
            base_events,
            case["limits"].get("replay"),
        )
        records, projection_digest = cre.evaluate_projection(
            world.json_values[projection_entry["path"]],
            events,
            counters,
        )
    except cre.CREError as exc:
        raise VerificationError(exc.code, exc.message, exc.context) from exc
    return ReplayState(
        branch=branch,
        projection=projection_digest,
        trace=cre.trace_digest(trace),
        records=records,
        counters=counters.as_value(),
        events=events,
        trace_items=trace,
    )


def replay_root_case(world: kit.ValidatedBundle, case: dict[str, Any]) -> ReplayState:
    logical = kit.resolve_logical_world(world, case["world"])
    root = cre.root_branch_id(world.bundle)
    try:
        base_events, branch, _ = cre.apply_branch(logical.base_events, world.bundle, [], root)
    except cre.CREError as exc:
        raise VerificationError(exc.code, exc.message, exc.context) from exc
    return evaluate_case_state(world, case, base_events, branch)


def replay_case(
    world: kit.ValidatedBundle,
    case: dict[str, Any],
    operations: list[dict[str, Any]],
    parent_branch: str,
    baseline: ReplayState | None = None,
    base_events: list[dict[str, Any]] | None = None,
) -> ReplayResult:
    logical = kit.resolve_logical_world(world, case["world"])
    replay_base = base_events if base_events is not None else [cre.load_event(value) for value in logical.base_events]
    baseline = baseline or evaluate_case_state(world, case, replay_base, parent_branch)
    try:
        branched, branch, _ = cre.apply_branch(
            replay_base,
            world.bundle,
            operations,
            parent_branch,
        )
    except cre.CREError as exc:
        raise VerificationError(exc.code, exc.message, exc.context) from exc
    if not operations and branch == baseline.branch:
        candidate = baseline
    else:
        candidate = evaluate_case_state(world, case, branched, branch)
    changed = sorted(set(baseline.events) ^ set(candidate.events), key=cre.parse_id)
    return ReplayResult(
        branch=candidate.branch,
        projection=candidate.projection,
        trace=candidate.trace,
        records=candidate.records,
        counters=candidate.counters,
        events=candidate.events,
        trace_items=candidate.trace_items,
        baseline=baseline,
        changed_event_ids=changed,
    )


@dataclass
class BranchHistoryResult:
    base_events: list[dict[str, Any]]
    branch: str
    steps: list[dict[str, Any]]


def resolve_input_history(
    world: kit.ValidatedBundle,
    case: dict[str, Any],
    history_value: Any,
    facts: set[str],
) -> BranchHistoryResult:
    logical = kit.resolve_logical_world(world, case["world"])
    base_events = [cre.load_event(value) for value in logical.base_events]
    root = cre.root_branch_id(world.bundle)
    if case["input_branch"] == "root":
        if history_value is not None:
            raise VerificationError("unexpected_history", "root-input case forbids a branch history")
        return BranchHistoryResult(base_events=base_events, branch=root, steps=[])

    if history_value is None:
        raise VerificationError("history_required", "non-root case requires a complete branch history")
    history = require_map(history_value, {"format", "bundle", "world", "steps"}, "witness.history")
    if history["format"] != "afterimage-branch-history/0.1":
        raise VerificationError("invalid_history", "branch history format is unsupported")
    if history["bundle"] != world.bundle or history["world"] != case["world"]:
        raise VerificationError("history_mismatch", "branch history does not match the witness bundle and world")
    steps_value = history["steps"]
    if not isinstance(steps_value, list) or not steps_value or len(steps_value) > MAX_HISTORY_STEPS:
        raise VerificationError("invalid_history", "branch history must contain 1 through 32 steps")

    case_values = world.json_values["cases/index.json"]["cases"]
    case_map = {item.get("id"): item for item in case_values if isinstance(item, dict)}
    expected_origin = case["input_branch"][len("history:"):]
    parent = root
    previous_case: str | None = None
    steps: list[dict[str, Any]] = []
    for index, step_value in enumerate(steps_value):
        step = require_map(step_value, {"case", "operations"}, f"witness.history.steps[{index}]")
        origin_id = step["case"]
        if not isinstance(origin_id, str) or origin_id not in case_map:
            raise VerificationError("invalid_history", "history step names an unknown case", {"index": index})
        if f"case:{origin_id}" not in facts:
            raise VerificationError("history_case_locked", "history step case has not been unlocked", {"case": origin_id})
        origin = validate_case_descriptor(case_map[origin_id], world)
        if origin["world"] != case["world"]:
            raise VerificationError("history_world_mismatch", "all history steps must use the target case world", {"case": origin_id})
        required_input = "root" if previous_case is None else f"history:{previous_case}"
        if origin["input_branch"] != required_input:
            raise VerificationError(
                "history_chain_mismatch",
                "history cases do not form the declared input-branch chain",
                {"case": origin_id, "index": index},
            )
        if not isinstance(step["operations"], list) or not step["operations"]:
            raise VerificationError("invalid_history", "history step operations must be a non-empty list", {"index": index})

        baseline = evaluate_case_state(world, origin, base_events, parent)
        policy_document = world.json_values[origin["intervention_policy"]]
        intervention = {
            "format": "afterimage-intervention/0.1",
            "bundle": world.bundle,
            "parent_branch": parent,
            "case": origin_id,
            "operations": step["operations"],
        }
        policy = validate_intervention(
            policy_document,
            intervention,
            witness_bundle=world.bundle,
            witness_case=origin_id,
            parent_branch=parent,
            base_events=base_events,
            known_events=baseline.events,
        )
        try:
            base_events, parent, _ = cre.apply_branch(base_events, world.bundle, policy.operations, parent)
        except cre.CREError as exc:
            raise VerificationError(exc.code, exc.message, exc.context) from exc
        steps.append({"case": origin_id, "operations": policy.operations})
        previous_case = origin_id

    if previous_case != expected_origin:
        raise VerificationError(
            "history_origin_mismatch",
            "branch history ends at the wrong case",
            {"expected_case": expected_origin},
        )
    return BranchHistoryResult(base_events=base_events, branch=parent, steps=steps)


def validation_event(topic: str, payload: Any, sequence: int) -> dict[str, Any]:
    return cre.make_event(
        {
            "topic": topic,
            "at": 0,
            "payload": payload,
            "parents": [],
            "origin": {"kind": "base", "source": "afterimage-verifier/0.1", "sequence": sequence},
        }
    )


def run_validator(
    validator_value: Any,
    *,
    answer: Any,
    intervention: Any,
    replay: ReplayResult,
    limits: dict[str, Any] | None,
    embedded_receipt: dict[str, Any] | None = None,
    family_result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    validator = require_map(validator_value, {"format", "program", "decision_projection"}, "validator")
    if validator["format"] != "afterimage-validator/0.1":
        fail("invalid_validator", "validator format is unsupported")
    replay_payload = {
        "branch": replay.branch,
        "projection": replay.projection,
        "trace": replay.trace,
        "records": replay.records,
        "active_event_count": len(replay.events),
        "active_event_ids": sorted(replay.events, key=cre.parse_id),
        "counters": replay.counters,
        "trace_items": replay.trace_items,
        "trace_event_ids": [item["event"] for item in replay.trace_items],
        "baseline_branch": replay.baseline.branch,
        "baseline_projection": replay.baseline.projection,
        "baseline_trace": replay.baseline.trace,
        "baseline_records": replay.baseline.records,
        "baseline_active_event_ids": sorted(replay.baseline.events, key=cre.parse_id),
        "changed_event_ids": replay.changed_event_ids,
    }
    validation_base = [
        validation_event("verify.answer", answer, 0),
        validation_event("verify.replay", replay_payload, 1),
        validation_event("verify.intervention", intervention, 2),
    ]
    for sequence, event_id in enumerate(sorted(replay.events, key=cre.parse_id), 3):
        validation_base.append(validation_event("verify.active", cre.event_view(replay.events[event_id]), sequence))
    offset = 3 + len(replay.events)
    for sequence, event_id in enumerate(sorted(replay.baseline.events, key=cre.parse_id), offset):
        validation_base.append(validation_event("verify.baseline-active", cre.event_view(replay.baseline.events[event_id]), sequence))
    if embedded_receipt is not None:
        validation_base.append(validation_event("verify.embedded", embedded_receipt, offset + len(replay.baseline.events)))
    if family_result is not None:
        validation_base.append(validation_event("verify.family", family_result, offset + len(replay.baseline.events) + 1))
    try:
        events, _trace, counters = cre.evaluate_world(validator["program"], validation_base, limits)
        decisions, _digest = cre.evaluate_projection(validator["decision_projection"], events, counters)
    except cre.CREError as exc:
        raise VerificationError("invalid_validator", exc.message, exc.context) from exc
    if len(decisions) != 1 or not isinstance(decisions[0], dict) or set(decisions[0]) != {"valid", "diagnostics", "metrics"}:
        fail("invalid_validator", "decision projection must produce exactly one decision map")
    decision = decisions[0]
    if not isinstance(decision["valid"], bool) or not isinstance(decision["diagnostics"], list) or not isinstance(decision["metrics"], dict):
        fail("invalid_validator", "decision fields have invalid types")
    diagnostics = []
    for item in decision["diagnostics"]:
        diagnostic = require_map(item, DIAGNOSTIC_KEYS, "validator diagnostic")
        if not isinstance(diagnostic["code"], str) or not isinstance(diagnostic["message"], str) or not isinstance(diagnostic["context"], dict):
            fail("invalid_validator", "validator diagnostic fields have invalid types")
        diagnostics.append(diagnostic)
    if decision["valid"] and diagnostics:
        fail("invalid_validator", "valid decision must not contain diagnostics")
    if not decision["valid"] and not diagnostics:
        fail("invalid_validator", "invalid decision must contain a diagnostic")
    return decision


def validate_claimed(claimed: Any, replay: ReplayResult) -> None:
    if claimed is None:
        return
    if not isinstance(claimed, dict) or set(claimed) - {"branch", "projection", "trace"}:
        raise VerificationError("invalid_claimed", "claimed must contain only branch/projection/trace")
    actual = {"branch": replay.branch, "projection": replay.projection, "trace": replay.trace}
    for key, value in claimed.items():
        try:
            cre.parse_id(value, f"claimed.{key}")
        except cre.CREError as exc:
            raise VerificationError("invalid_claimed", exc.message, {"field": key}) from exc
        if value != actual[key]:
            raise VerificationError("claimed_mismatch", "claimed digest does not match replay", {"field": key})


def orient_score(case: dict[str, Any], score_value: Any, answer: Any, validator_metrics: dict[str, Any]) -> tuple[dict[str, int], dict[str, int]]:
    if not isinstance(score_value, dict) or set(score_value) not in (
        {"format", "family", "reference_scale", "metric_bounds"},
        {"format", "family", "reference_scale", "metric_bounds", "grants"},
    ):
        fail("invalid_score", "ORIENT score descriptor has wrong fields")
    score = score_value
    if score["format"] != "afterimage-score/0.1" or score["family"] != "ORIENT" or case["family"] != "ORIENT":
        fail("invalid_score", "ORIENT score descriptor is invalid")
    scale = score["reference_scale"]
    if isinstance(scale, bool) or not isinstance(scale, int) or scale <= 0:
        fail("invalid_score", "reference_scale must be positive")
    bounds = require_map(score["metric_bounds"], {"witness_units"}, "score.metric_bounds")
    grants = score.get("grants", [])
    if (
        not isinstance(grants, list)
        or len(set(grants)) != len(grants)
        or not all(isinstance(item, str) and item.startswith("cap:") for item in grants)
    ):
        fail("invalid_score", "score grants must be unique capability facts")
    max_units = checked_nonnegative(bounds["witness_units"], "score.metric_bounds.witness_units")
    if set(validator_metrics) != {"wrong_or_redundant_claims"} or validator_metrics["wrong_or_redundant_claims"] != 0:
        fail("invalid_validator", "valid ORIENT decision must report zero wrong claims")
    units = (len(cre.canonical_bytes(answer)) + 31) // 32
    if units > max_units:
        raise VerificationError("metric_limit", "answer exceeds witness_units bound", {"value": units, "maximum": max_units})
    effective = units + 1
    points = case["points"]
    completion = (65 * points + 99) // 100
    pool = points - completion
    quality_ppm = 1_000_000 * scale // (scale + effective)
    optimization = pool * quality_ppm // 1_000_000
    metrics = {
        "wrong_or_redundant_claims": 0,
        "witness_units": units,
        "effective_cost": effective,
    }
    score_result = {
        "completion": completion,
        "optimization": optimization,
        "total": completion + optimization,
        "nominal_max": points,
    }
    return metrics, score_result


def cascade_score(
    case: dict[str, Any],
    score_value: Any,
    answer: Any,
    validator_metrics: dict[str, Any],
    policy: PolicyResult,
    replay: ReplayResult,
) -> tuple[dict[str, int], dict[str, int]]:
    if not isinstance(score_value, dict) or set(score_value) not in (
        {"format", "family", "reference_scale", "metric_bounds", "diagnostic_topics"},
        {"format", "family", "reference_scale", "metric_bounds", "diagnostic_topics", "proof_contract"},
    ):
        fail("invalid_score", "CASCADE score descriptor fields are invalid")
    score = score_value
    if score["format"] != "afterimage-score/0.1" or score["family"] != "CASCADE" or case["family"] != "CASCADE":
        fail("invalid_score", "CASCADE score descriptor is invalid")
    scale = score["reference_scale"]
    if isinstance(scale, bool) or not isinstance(scale, int) or scale <= 0:
        fail("invalid_score", "reference_scale must be positive")
    bounds = require_map(score["metric_bounds"], {"causal_footprint", "witness_units"}, "score.metric_bounds")
    max_footprint = checked_nonnegative(bounds["causal_footprint"], "score.metric_bounds.causal_footprint")
    max_units = checked_nonnegative(bounds["witness_units"], "score.metric_bounds.witness_units")
    topics = score["diagnostic_topics"]
    if not isinstance(topics, list) or len(set(topics)) != len(topics) or not all(isinstance(item, str) for item in topics):
        fail("invalid_score", "diagnostic_topics must be a unique Text list")
    expected_validator_metric = "proof_failures" if "proof_contract" in score else "contract_violations"
    if set(validator_metrics) != {expected_validator_metric} or validator_metrics[expected_validator_metric] != 0:
        fail("invalid_validator", f"valid CASCADE decision must report zero {expected_validator_metric.replace('_', ' ')}")
    all_events = {**replay.baseline.events, **replay.events}
    footprint = sum(all_events[event_id]["topic"] not in set(topics) for event_id in replay.changed_event_ids)
    units = (len(cre.canonical_bytes(answer)) + 63) // 64
    if footprint > max_footprint or units > max_units:
        raise VerificationError("metric_limit", "CASCADE metric exceeds public bound", {"causal_footprint": footprint, "witness_units": units})
    effective = ((policy.weight * (max_footprint + 1) + footprint) * (max_units + 1) + units) + 1
    points = case["points"]
    completion = (65 * points + 99) // 100
    pool = points - completion
    quality_ppm = 1_000_000 * scale // (scale + effective)
    optimization = pool * quality_ppm // 1_000_000
    metrics = {
        "intervention_weight": policy.weight,
        "causal_footprint": footprint,
        "witness_units": units,
        "effective_cost": effective,
    }
    return metrics, {
        "completion": completion,
        "optimization": optimization,
        "total": completion + optimization,
        "nominal_max": points,
    }


def validate_cascade_proof(answer: Any, replay: ReplayResult, policy: PolicyResult, proof: Any) -> dict[str, int]:
    proof = require_map(proof, {"relay_topic", "ready_topic", "policy_label", "relay_id", "capability_scope", "reroute_id"}, "score.proof_contract")
    answer = require_map(answer, {"contract", "public_rows", "relay", "branch", "projection"}, "CASCADE proof answer")
    relay_claim = require_map(answer["relay"], {"event", "relay_id", "provenance_digest", "projection_difference", "policy_label"}, "answer.relay")
    relays = [event for event in replay.events.values() if event["topic"] == proof["relay_topic"]]
    ready = [event for event in replay.events.values() if event["topic"] == proof["ready_topic"]]
    if len(relays) != 1 or len(ready) != 1:
        raise VerificationError("cascade_proof", "active route proof is incomplete")
    relay = relays[0]
    expected_digest = cre.digest_id("afterimage/provenance/1", cre.canonical_bytes(relay["payload"]["provenance"]))
    expected_relay = {
        "event": relay["id"], "relay_id": proof["relay_id"], "provenance_digest": expected_digest,
        "projection_difference": "whole_event_suppressed", "policy_label": proof["policy_label"],
    }
    if not cre.same_value(relay_claim, expected_relay):
        raise VerificationError("cascade_proof", "relay provenance certificate is invalid")
    if not cre.same_value(answer["contract"], ready[0]["payload"]) or answer["contract"].get("safe") is not True:
        raise VerificationError("cascade_proof", "evacuation contract is not satisfied")
    if not cre.same_value(answer["public_rows"], replay.records) or answer["branch"] != replay.branch or answer["projection"] != replay.projection:
        raise VerificationError("cascade_proof", "proof does not bind the independent replay")
    unavailable = [row for row in replay.records if isinstance(row, dict) and row.get("edge") == proof["relay_id"]]
    if unavailable != [{"edge": proof["relay_id"], "status": "unavailable", "policy": proof["policy_label"]}]:
        raise VerificationError("cascade_proof", "public projection does not expose the declared suppression")
    for operation in policy.operations:
        if operation["kind"] != "inject":
            raise VerificationError("cascade_proof", "reveal proof permits only scoped injections")
        if operation["topic"] == "audit.capability":
            if operation["payload"] != {"capability": "audit.relay", "scope": proof["capability_scope"]}:
                raise VerificationError("cascade_proof", "audit capability is not scoped to this case")
        elif operation["topic"] == "route.reroute":
            if operation["payload"] != {"route": proof["reroute_id"]}:
                raise VerificationError("cascade_proof", "physical reroute payload is invalid")
    return {"proof_failures": 0}


def validate_merge_answer(world: kit.ValidatedBundle, case: dict[str, Any], answer: Any) -> dict[str, int]:
    answer = require_map(answer, {"accepted", "rejected", "certificate"}, "MERGE answer")
    logical = kit.resolve_logical_world(world, case["world"])
    records = {event["id"]: event for event in logical.base_events if event["topic"] == "merge.record"}
    if not records:
        fail("invalid_case", "MERGE case has no records")
    for event_id, event in records.items():
        payload = event.get("payload")
        required = {"key", "local_time", "offset_min", "offset_max", "source", "sequence", "weight"}
        if not isinstance(payload, dict) or not required.issubset(payload):
            raise VerificationError("invalid_case", "MERGE record payload is incomplete", {"event": event_id})
        if not isinstance(payload["key"], str) or not payload["key"] or not isinstance(payload["source"], str) or not payload["source"]:
            raise VerificationError("invalid_case", "MERGE record identity is invalid", {"event": event_id})
        for field in ("local_time", "offset_min", "offset_max", "sequence", "weight"):
            if isinstance(payload[field], bool) or not isinstance(payload[field], int):
                raise VerificationError("invalid_case", "MERGE record integer field is invalid", {"event": event_id, "field": field})
        if payload["offset_min"] > payload["offset_max"] or payload["sequence"] < 0 or payload["weight"] < 0:
            raise VerificationError("invalid_case", "MERGE record bounds are invalid", {"event": event_id})
    accepted: dict[str, int] = {}
    for index, item in enumerate(answer["accepted"] if isinstance(answer["accepted"], list) else []):
        item = require_map(item, {"event", "at"}, f"answer.accepted/{index}")
        if not isinstance(item["event"], str) or item["event"] not in records or item["event"] in accepted or isinstance(item["at"], bool) or not isinstance(item["at"], int):
            raise VerificationError("merge_classification", "accepted record entry is invalid", {"index": index})
        accepted[item["event"]] = item["at"]
    rejected: dict[str, str] = {}
    for index, item in enumerate(answer["rejected"] if isinstance(answer["rejected"], list) else []):
        item = require_map(item, {"event", "reason"}, f"answer.rejected/{index}")
        if not isinstance(item["event"], str) or item["event"] not in records or item["event"] in rejected or not isinstance(item["reason"], str):
            raise VerificationError("merge_classification", "rejected record entry is invalid", {"index": index})
        rejected[item["event"]] = item["reason"]
    if set(accepted) & set(rejected) or set(accepted) | set(rejected) != set(records):
        raise VerificationError("merge_classification", "every record must be classified exactly once")

    def interval(event: dict[str, Any]) -> tuple[int, int]:
        payload = event["payload"]
        try:
            lo = payload["local_time"] - payload["offset_max"]
            hi = payload["local_time"] - payload["offset_min"]
        except (KeyError, TypeError) as exc:
            raise VerificationError("invalid_case", "MERGE record interval payload is invalid") from exc
        return lo, hi

    for event_id, at in accepted.items():
        lo, hi = interval(records[event_id])
        if not lo <= at <= hi:
            raise VerificationError("merge_interval", "assigned time is outside record interval", {"event": event_id})
    required: set[tuple[str, str, int]] = set()
    for child_id in accepted:
        child = records[child_id]
        for parent_id in child["parents"]:
            if parent_id in accepted:
                required.add((parent_id, child_id, 1))
                if accepted[parent_id] + 1 > accepted[child_id]:
                    raise VerificationError("merge_order", "message parent does not precede child", {"before": parent_id, "after": child_id})
    by_source: dict[str, list[str]] = {}
    for event_id in accepted:
        by_source.setdefault(records[event_id]["payload"]["source"], []).append(event_id)
    for ids in by_source.values():
        ids.sort(key=lambda value: records[value]["payload"]["sequence"])
        for before, after in zip(ids, ids[1:]):
            required.add((before, after, 1))
            if accepted[before] + 1 > accepted[after]:
                raise VerificationError("merge_order", "source sequence does not increase", {"before": before, "after": after})
    supplied: set[tuple[str, str, int]] = set()
    if not isinstance(answer["certificate"], list):
        raise VerificationError("merge_certificate", "certificate must be a list")
    for index, item in enumerate(answer["certificate"]):
        item = require_map(item, {"before", "after", "minimum_gap"}, f"answer.certificate/{index}")
        if (
            not isinstance(item["before"], str)
            or not isinstance(item["after"], str)
            or isinstance(item["minimum_gap"], bool)
            or not isinstance(item["minimum_gap"], int)
            or item["minimum_gap"] < 0
        ):
            raise VerificationError("merge_certificate", "certificate edge fields are invalid", {"index": index})
        edge = (item["before"], item["after"], item["minimum_gap"])
        if edge in supplied:
            raise VerificationError("merge_certificate", "certificate edge is duplicated")
        supplied.add(edge)
    if supplied != required:
        raise VerificationError("merge_certificate", "certificate does not exactly cover active order constraints")
    for event_id, reason in rejected.items():
        if reason not in {"inconsistent", "conflict_set"}:
            raise VerificationError("merge_rejection", "unsupported rejection reason", {"event": event_id})
        if reason == "conflict_set":
            continue
        lo, hi = interval(records[event_id])
        event = records[event_id]
        for parent in event["parents"]:
            if parent in accepted:
                lo = max(lo, accepted[parent] + 1)
        for child_id, child in records.items():
            if child_id in accepted and event_id in child["parents"]:
                hi = min(hi, accepted[child_id] - 1)
        same = [(other["payload"]["sequence"], other_id) for other_id, other in records.items() if other_id in accepted and other["payload"]["source"] == event["payload"]["source"]]
        for sequence, other_id in same:
            if sequence < event["payload"]["sequence"]:
                lo = max(lo, accepted[other_id] + 1)
            elif sequence > event["payload"]["sequence"]:
                hi = min(hi, accepted[other_id] - 1)
        if lo <= hi:
            raise VerificationError("merge_rejection", "rejected record remains feasible under submitted schedule", {"event": event_id})
    conflict_set = {event_id for event_id, reason in rejected.items() if reason == "conflict_set"}
    if conflict_set:
        if len(conflict_set) < 2:
            raise VerificationError("merge_rejection", "conflict_set requires at least two records")
        selected = set(accepted) | conflict_set
        lower = {event_id: accepted[event_id] if event_id in accepted else interval(records[event_id])[0] for event_id in selected}
        upper = {event_id: accepted[event_id] if event_id in accepted else interval(records[event_id])[1] for event_id in selected}
        edges: set[tuple[str, str]] = set()
        for child_id in selected:
            edges.update((parent_id, child_id) for parent_id in records[child_id]["parents"] if parent_id in selected)
        selected_by_source: dict[str, list[str]] = {}
        for event_id in selected:
            selected_by_source.setdefault(records[event_id]["payload"]["source"], []).append(event_id)
        for ids in selected_by_source.values():
            ids.sort(key=lambda value: records[value]["payload"]["sequence"])
            edges.update(zip(ids, ids[1:]))
        infeasible = False
        for _iteration in range(len(selected)):
            changed = False
            for before, after in edges:
                candidate = lower[before] + 1
                if candidate > lower[after]:
                    lower[after] = candidate
                    changed = True
                    if candidate > upper[after]:
                        infeasible = True
                        break
            if infeasible or not changed:
                break
        else:
            infeasible = True
        if not infeasible:
            raise VerificationError("merge_rejection", "conflict_set records remain jointly feasible")
    displacement = sum(abs(at - sum(interval(records[event_id])) // 2) for event_id, at in accepted.items())
    return {
        "rejected_weight": sum(records[event_id]["payload"]["weight"] for event_id in rejected),
        "temporal_displacement": displacement,
        "certificate_units": (len(cre.canonical_bytes(answer["certificate"])) + 63) // 64,
    }


def merge_score(case: dict[str, Any], score_value: Any, raw: dict[str, int]) -> tuple[dict[str, int], dict[str, int]]:
    score = require_map(score_value, {"format", "family", "reference_scale", "metric_bounds"}, "score")
    if score["format"] != "afterimage-score/0.1" or score["family"] != "MERGE" or case["family"] != "MERGE":
        fail("invalid_score", "MERGE score descriptor is invalid")
    bounds = require_map(score["metric_bounds"], {"temporal_displacement", "certificate_units"}, "score.metric_bounds")
    displacement_bound = checked_nonnegative(bounds["temporal_displacement"], "score.metric_bounds.temporal_displacement")
    certificate_bound = checked_nonnegative(bounds["certificate_units"], "score.metric_bounds.certificate_units")
    if raw["temporal_displacement"] > displacement_bound or raw["certificate_units"] > certificate_bound:
        raise VerificationError("metric_limit", "MERGE metric exceeds public bound")
    effective = ((raw["rejected_weight"] * (displacement_bound + 1) + raw["temporal_displacement"]) * (certificate_bound + 1) + raw["certificate_units"]) + 1
    metrics = {**raw, "effective_cost": effective}
    points, scale = case["points"], score["reference_scale"]
    completion = (65 * points + 99) // 100
    pool = points - completion
    optimization = pool * (1_000_000 * scale // (scale + effective)) // 1_000_000
    return metrics, {"completion": completion, "optimization": optimization, "total": completion + optimization, "nominal_max": points}


def validate_pulse_answer(score_value: Any, answer: Any) -> dict[str, int]:
    if not isinstance(answer, dict) or set(answer) not in ({"program"}, {"program", "invariant"}):
        raise VerificationError("invalid_schema", "PULSE answer fields are invalid")
    try:
        return pulse_runtime.verify_program(answer["program"], score_value.get("contract") if isinstance(score_value, dict) else None)
    except pulse_runtime.PulseError as exc:
        raise VerificationError(exc.code, exc.message, exc.context) from exc


def pulse_score(case: dict[str, Any], score_value: Any, raw: dict[str, int]) -> tuple[dict[str, int], dict[str, int]]:
    score = require_map(score_value, {"format", "family", "reference_scale", "metric_bounds", "contract"}, "score")
    if score["format"] != "afterimage-score/0.1" or score["family"] != "PULSE" or case["family"] != "PULSE":
        fail("invalid_score", "PULSE score descriptor is invalid")
    scale = checked_nonnegative(score["reference_scale"], "score.reference_scale")
    if scale <= 0:
        fail("invalid_score", "PULSE reference scale must be positive")
    bounds = require_map(score["metric_bounds"], {"worst_latency", "live_state_cells"}, "score.metric_bounds")
    latency_bound = checked_nonnegative(bounds["worst_latency"], "score.metric_bounds.worst_latency")
    state_bound = checked_nonnegative(bounds["live_state_cells"], "score.metric_bounds.live_state_cells")
    if raw["worst_latency"] > latency_bound or raw["live_state_cells"] > state_bound:
        raise VerificationError("metric_limit", "PULSE metric exceeds public bound")
    effective = ((raw["program_bytes"] * (latency_bound + 1) + raw["worst_latency"]) * (state_bound + 1) + raw["live_state_cells"]) + 1
    metrics = {key: raw[key] for key in ("program_bytes", "worst_latency", "live_state_cells")}
    metrics["effective_cost"] = effective
    points = case["points"]
    completion = (65 * points + 99) // 100
    pool = points - completion
    optimization = pool * (1_000_000 * scale // (scale + effective)) // 1_000_000
    return metrics, {"completion": completion, "optimization": optimization, "total": completion + optimization, "nominal_max": points}


def validate_mosaic_answer(world: kit.ValidatedBundle, case: dict[str, Any], score_value: Any, answer: Any) -> dict[str, int]:
    logical = kit.resolve_logical_world(world, case["world"])
    fragments = [event["payload"] for event in logical.base_events if event["topic"] == "mosaic.fragment"]
    try:
        return mosaic_runtime.validate_answer(fragments, answer, score_value.get("contract") if isinstance(score_value, dict) else None)
    except mosaic_runtime.MosaicError as exc:
        raise VerificationError(exc.code, exc.message, exc.context) from exc


def mosaic_score(case: dict[str, Any], score_value: Any, raw: dict[str, int]) -> tuple[dict[str, int], dict[str, int]]:
    score = require_map(score_value, {"format", "family", "reference_scale", "metric_bounds", "contract"}, "score")
    if score["format"] != "afterimage-score/0.1" or score["family"] != "MOSAIC" or case["family"] != "MOSAIC":
        fail("invalid_score", "MOSAIC score descriptor is invalid")
    scale = checked_nonnegative(score["reference_scale"], "score.reference_scale")
    if scale <= 0:
        fail("invalid_score", "MOSAIC reference scale must be positive")
    bounds = require_map(score["metric_bounds"], {"graph_size", "certificate_units"}, "score.metric_bounds")
    graph_bound = checked_nonnegative(bounds["graph_size"], "score.metric_bounds.graph_size")
    certificate_bound = checked_nonnegative(bounds["certificate_units"], "score.metric_bounds.certificate_units")
    if raw["graph_size"] > graph_bound or raw["certificate_units"] > certificate_bound:
        raise VerificationError("metric_limit", "MOSAIC metric exceeds public bound")
    effective = ((raw["unexplained_weight"] * (graph_bound + 1) + raw["graph_size"]) * (certificate_bound + 1) + raw["certificate_units"]) + 1
    metrics = {**raw, "effective_cost": effective}
    points = case["points"]
    completion = (65 * points + 99) // 100
    pool = points - completion
    optimization = pool * (1_000_000 * scale // (scale + effective)) // 1_000_000
    return metrics, {"completion": completion, "optimization": optimization, "total": completion + optimization, "nominal_max": points}


def validate_lens_answer(score_value: Any, answer: Any) -> dict[str, int]:
    answer = require_map(answer, {"program"}, "LENS answer")
    try:
        return lens_runtime.verify_program(answer["program"], score_value.get("contract") if isinstance(score_value, dict) else None)
    except lens_runtime.LensError as exc:
        raise VerificationError(exc.code, exc.message, exc.context) from exc


def lens_score(case: dict[str, Any], score_value: Any, raw: dict[str, int]) -> tuple[dict[str, int], dict[str, int]]:
    score = require_map(score_value, {"format", "family", "reference_scale", "metric_bounds", "contract"}, "score")
    if score["format"] != "afterimage-score/0.1" or score["family"] != "LENS" or case["family"] != "LENS":
        fail("invalid_score", "LENS score descriptor is invalid")
    scale = checked_nonnegative(score["reference_scale"], "score.reference_scale")
    if scale <= 0:
        fail("invalid_score", "LENS reference scale must be positive")
    bounds = require_map(score["metric_bounds"], {"auxiliary_schema_cells", "worst_reductions"}, "score.metric_bounds")
    auxiliary_bound = checked_nonnegative(bounds["auxiliary_schema_cells"], "score.metric_bounds.auxiliary_schema_cells")
    reduction_bound = checked_nonnegative(bounds["worst_reductions"], "score.metric_bounds.worst_reductions")
    if raw["auxiliary_schema_cells"] > auxiliary_bound or raw["worst_reductions"] > reduction_bound:
        raise VerificationError("metric_limit", "LENS metric exceeds public bound")
    effective = ((raw["program_nodes"] * (auxiliary_bound + 1) + raw["auxiliary_schema_cells"]) * (reduction_bound + 1) + raw["worst_reductions"]) + 1
    metrics = {key: raw[key] for key in ("program_nodes", "auxiliary_schema_cells", "worst_reductions")}
    metrics["effective_cost"] = effective
    points = case["points"]
    completion = (65 * points + 99) // 100
    pool = points - completion
    optimization = pool * (1_000_000 * scale // (scale + effective)) // 1_000_000
    return metrics, {"completion": completion, "optimization": optimization, "total": completion + optimization, "nominal_max": points}


def validate_covenant_answer(score_value: Any, answer: Any) -> dict[str, int]:
    answer = require_map(answer, {"policy", "claimed_response_bound"}, "COVENANT answer")
    claimed = checked_nonnegative(answer["claimed_response_bound"], "COVENANT answer.claimed_response_bound")
    if not isinstance(score_value, dict) or "contract" not in score_value:
        fail("invalid_score", "COVENANT score descriptor lacks a contract")
    try:
        metrics = covenant_runtime.verify_policy(score_value["contract"], answer["policy"])
    except covenant_runtime.CovenantError as exc:
        raise VerificationError(exc.code, exc.message, exc.context) from exc
    if claimed != metrics["worst_response_bound"]:
        raise VerificationError("covenant_claim", "claimed response bound differs from exhaustive model checking")
    return metrics


def covenant_score(case: dict[str, Any], score_value: Any, raw: dict[str, int]) -> tuple[dict[str, int], dict[str, int]]:
    score = require_map(score_value, {"format", "family", "reference_scale", "metric_bounds", "contract"}, "score")
    if score["format"] != "afterimage-score/0.1" or score["family"] != "COVENANT" or case["family"] != "COVENANT":
        fail("invalid_score", "COVENANT score descriptor is invalid")
    scale = checked_nonnegative(score["reference_scale"], "score.reference_scale")
    if scale <= 0:
        fail("invalid_score", "COVENANT reference scale must be positive")
    bounds = require_map(score["metric_bounds"], {"worst_response_bound", "reachable_states"}, "score.metric_bounds")
    response_bound = checked_nonnegative(bounds["worst_response_bound"], "score.metric_bounds.worst_response_bound")
    states_bound = checked_nonnegative(bounds["reachable_states"], "score.metric_bounds.reachable_states")
    if raw["worst_response_bound"] > response_bound or raw["reachable_states"] > states_bound:
        raise VerificationError("metric_limit", "COVENANT metric exceeds public bound")
    effective = ((raw["policy_nodes"] * (response_bound + 1) + raw["worst_response_bound"]) * (states_bound + 1) + raw["reachable_states"]) + 1
    metrics = {**raw, "effective_cost": effective}
    points = case["points"]
    completion = (65 * points + 99) // 100
    pool = points - completion
    optimization = pool * (1_000_000 * scale // (scale + effective)) // 1_000_000
    return metrics, {"completion": completion, "optimization": optimization, "total": completion + optimization, "nominal_max": points}


def validate_paradox_answer(
    world: kit.ValidatedBundle,
    case: dict[str, Any],
    score_value: Any,
    answer: Any,
    facts: set[str],
) -> dict[str, int]:
    answer_map = require_map(answer, {"left_history", "right_history", "equivalence", "safety_evidence", "latent_difference"}, "PARADOX answer")
    if not isinstance(score_value, dict) or "contract" not in score_value:
        fail("invalid_score", "PARADOX score descriptor lacks a contract")
    replays: dict[str, ReplayState] = {}
    for side in ("left", "right"):
        history = answer_map[f"{side}_history"]
        if not isinstance(history, dict) or not isinstance(history.get("steps"), list) or not history["steps"]:
            raise VerificationError("paradox_history", "paired branch history is missing or empty", {"side": side})
        final_step = history["steps"][-1]
        if not isinstance(final_step, dict) or not isinstance(final_step.get("case"), str):
            raise VerificationError("paradox_history", "paired branch history has an invalid final step", {"side": side})
        target = {**case, "input_branch": f"history:{final_step['case']}"}
        history_result = resolve_input_history(world, target, history, facts)
        replays[side] = evaluate_case_state(world, case, history_result.base_events, history_result.branch)
    try:
        return paradox_runtime.validate_certificate(
            score_value["contract"],
            answer_map,
            left_branch=replays["left"].branch,
            right_branch=replays["right"].branch,
            left_records=replays["left"].records,
            right_records=replays["right"].records,
            left_events=replays["left"].events,
            right_events=replays["right"].events,
        )
    except paradox_runtime.ParadoxError as exc:
        raise VerificationError(exc.code, exc.message, exc.context) from exc


def paradox_score(case: dict[str, Any], score_value: Any, raw: dict[str, int]) -> tuple[dict[str, int], dict[str, int]]:
    score = require_map(score_value, {"format", "family", "reference_scale", "metric_bounds", "contract"}, "score")
    if score["format"] != "afterimage-score/0.1" or score["family"] != "PARADOX" or case["family"] != "PARADOX":
        fail("invalid_score", "PARADOX score descriptor is invalid")
    scale = checked_nonnegative(score["reference_scale"], "score.reference_scale")
    if scale <= 0:
        fail("invalid_score", "PARADOX reference scale must be positive")
    bounds = require_map(score["metric_bounds"], {"latent_difference_weight", "proof_steps"}, "score.metric_bounds")
    difference_bound = checked_nonnegative(bounds["latent_difference_weight"], "score.metric_bounds.latent_difference_weight")
    proof_bound = checked_nonnegative(bounds["proof_steps"], "score.metric_bounds.proof_steps")
    if raw["latent_difference_weight"] <= 0:
        raise VerificationError("paradox_no_difference", "PARADOX latent difference must be non-zero")
    if raw["latent_difference_weight"] > difference_bound or raw["proof_steps"] > proof_bound:
        raise VerificationError("metric_limit", "PARADOX metric exceeds public bound")
    effective = ((raw["paired_witness_units"] * (difference_bound + 1) + raw["latent_difference_weight"]) * (proof_bound + 1) + raw["proof_steps"]) + 1
    metrics = {**raw, "effective_cost": effective}
    points = case["points"]
    completion = (65 * points + 99) // 100
    pool = points - completion
    optimization = pool * (1_000_000 * scale // (scale + effective)) // 1_000_000
    return metrics, {"completion": completion, "optimization": optimization, "total": completion + optimization, "nominal_max": points}


def invalid_receipt(
    world: kit.ValidatedBundle,
    case_id: str,
    witness_digest: str,
    diagnostic: dict[str, Any],
    replay: ReplayResult | None = None,
) -> dict[str, Any]:
    receipt = {
        "format": "afterimage-receipt/0.1",
        "valid": False,
        "bundle": world.bundle,
        "case": case_id,
        "witness": witness_digest,
        "diagnostics": [diagnostic],
    }
    if replay is not None:
        receipt.update({"branch": replay.branch, "projection": replay.projection, "trace": replay.trace})
    return receipt


def verify_witness_bytes(
    world: kit.ValidatedBundle,
    witness_bytes: bytes,
    source: str,
    facts: Iterable[str] = (),
    depth: int = 0,
) -> dict[str, Any]:
    fact_set = set(facts)
    if len(witness_bytes) > MAX_WITNESS_BYTES:
        fail("limit_exceeded", "witness exceeds verifier hard limit")
    try:
        witness = kit.decode_json(witness_bytes, source)
    except kit.KitError as exc:
        raise VerificationError(exc.code, exc.message, exc.context) from exc
    if not isinstance(witness, dict) or not WITNESS_REQUIRED.issubset(witness) or set(witness) - (WITNESS_REQUIRED | WITNESS_OPTIONAL):
        fail("invalid_witness", "witness outer fields are invalid")
    if witness["format"] != "afterimage-witness/0.1" or witness["semantics"] != "cre/0.1":
        fail("invalid_witness", "witness format or semantics is unsupported")
    if "meta" in witness:
        meta = witness["meta"]
        if not isinstance(meta, dict) or not meta or set(meta) - {"producer", "comment"}:
            fail("invalid_witness", "witness meta fields are invalid")
        if not all(isinstance(value, str) for value in meta.values()):
            fail("invalid_witness", "witness meta values must be Text")
    if witness["bundle"] != world.bundle:
        fail("bundle_mismatch", "witness names a different bundle")
    if not isinstance(witness["case"], str):
        fail("invalid_witness", "witness case must be Text")
    witness_digest = cre.digest_id("afterimage/witness/1", witness_bytes)

    descriptors = {item.get("id"): item for item in world.json_values["cases/index.json"]["cases"] if isinstance(item, dict)}
    if witness["case"] not in descriptors:
        fail("unknown_case", "witness case is absent from bundle", case=witness["case"])
    case = validate_case_descriptor(descriptors[witness["case"]], world)
    witness_limit = case["limits"].get("max_witness_bytes", MAX_WITNESS_BYTES)
    if len(witness_bytes) > witness_limit:
        return invalid_receipt(world, case["id"], witness_digest, VerificationError("limit_exceeded", "witness exceeds case limit").diagnostic())
    if not requirements_hold(case["requires"], fact_set):
        return invalid_receipt(world, case["id"], witness_digest, VerificationError("case_locked", "case prerequisites are not satisfied").diagnostic())
    try:
        input_history = resolve_input_history(world, case, witness.get("history"), fact_set)
    except (VerificationError, cre.CREError) as exc:
        error = exc if isinstance(exc, VerificationError) else VerificationError(exc.code, exc.message, exc.context)
        return invalid_receipt(world, case["id"], witness_digest, error.diagnostic())
    expected_parent = input_history.branch
    if witness["parent_branch"] != expected_parent:
        return invalid_receipt(world, case["id"], witness_digest, VerificationError("parent_branch_mismatch", "witness uses the wrong input branch").diagnostic())

    base_events = input_history.base_events
    try:
        embedded_policy = validate_answer_schema(world.json_values[case["answer_schema"]], witness["answer"])
        embedded_receipt = None
        if embedded_policy is not None:
            if depth >= 1:
                raise VerificationError("embedded_depth", "embedded witnesses may not contain another embedded witness")
            embedded_witness = cre.pointer_get(witness["answer"], embedded_policy["pointer"])
            if not isinstance(embedded_witness, dict) or not isinstance(embedded_witness.get("case"), str):
                raise VerificationError("embedded_witness_invalid", "embedded witness must be a witness map with a case")
            embedded_case = embedded_witness["case"]
            if embedded_case not in embedded_policy["allowed_cases"]:
                raise VerificationError("embedded_case_forbidden", "embedded witness case is outside the export policy", {"case": embedded_case})
            if embedded_policy["require_fact"] and f"case:{embedded_case}" not in fact_set:
                raise VerificationError("embedded_case_locked", "embedded witness case has not been unlocked", {"case": embedded_case})
            try:
                embedded_receipt = verify_witness_bytes(
                    world,
                    cre.canonical_bytes(embedded_witness),
                    f"{source}#{embedded_policy['pointer']}",
                    fact_set,
                    depth + 1,
                )
            except VerificationError as exc:
                raise VerificationError(
                    "embedded_witness_invalid",
                    "embedded witness failed outer-envelope validation",
                    {"inner_code": exc.code},
                ) from exc
            if not embedded_receipt["valid"]:
                inner = embedded_receipt["diagnostics"][0]
                raise VerificationError(
                    "embedded_witness_invalid",
                    "embedded witness failed independent verification",
                    {"case": embedded_case, "inner_code": inner["code"]},
                )
        score_document = world.json_values[case["score"]]
        family_result = None
        merge_metrics = None
        pulse_metrics = None
        mosaic_metrics = None
        lens_metrics = None
        covenant_metrics = None
        paradox_metrics = None
        if case["family"] == "MERGE":
            merge_metrics = validate_merge_answer(world, case, witness["answer"])
            family_result = {"valid": True, "metrics": merge_metrics}
        elif case["family"] == "PULSE":
            pulse_metrics = validate_pulse_answer(score_document, witness["answer"])
            family_result = {"valid": True, "metrics": pulse_metrics}
        elif case["family"] == "MOSAIC":
            mosaic_metrics = validate_mosaic_answer(world, case, score_document, witness["answer"])
            family_result = {"valid": True, "metrics": mosaic_metrics}
        elif case["family"] == "LENS":
            lens_metrics = validate_lens_answer(score_document, witness["answer"])
            family_result = {"valid": True, "metrics": lens_metrics}
        elif case["family"] == "COVENANT":
            covenant_metrics = validate_covenant_answer(score_document, witness["answer"])
            family_result = {"valid": True, "metrics": covenant_metrics}
        elif case["family"] == "PARADOX":
            paradox_metrics = validate_paradox_answer(world, case, score_document, witness["answer"], fact_set)
            family_result = {"valid": True, "metrics": paradox_metrics}
        baseline = evaluate_case_state(world, case, base_events, expected_parent)
        policy = validate_intervention(
            world.json_values[case["intervention_policy"]],
            witness["intervention"],
            witness_bundle=world.bundle,
            witness_case=case["id"],
            parent_branch=expected_parent,
            base_events=base_events,
            known_events=baseline.events,
        )
        replay = replay_case(world, case, policy.operations, expected_parent, baseline, base_events)
        if case["family"] == "CASCADE" and isinstance(score_document, dict) and "proof_contract" in score_document:
            family_result = {"valid": True, "metrics": validate_cascade_proof(witness["answer"], replay, policy, score_document["proof_contract"])}
        validate_claimed(witness.get("claimed"), replay)
        decision = run_validator(
            world.json_values[case["validator"]],
            answer=witness["answer"],
            intervention=witness["intervention"],
            replay=replay,
            limits=case["limits"].get("validator"),
            embedded_receipt=embedded_receipt,
            family_result=family_result,
        )
        if not decision["valid"]:
            return invalid_receipt(world, case["id"], witness_digest, decision["diagnostics"][0], replay)
        if case["family"] == "ORIENT":
            metrics, score = orient_score(case, score_document, witness["answer"], decision["metrics"])
        elif case["family"] == "CASCADE":
            metrics, score = cascade_score(case, score_document, witness["answer"], decision["metrics"], policy, replay)
        elif case["family"] == "MERGE":
            metrics, score = merge_score(case, score_document, merge_metrics or {})
        elif case["family"] == "PULSE":
            metrics, score = pulse_score(case, score_document, pulse_metrics or {})
        elif case["family"] == "MOSAIC":
            metrics, score = mosaic_score(case, score_document, mosaic_metrics or {})
        elif case["family"] == "LENS":
            metrics, score = lens_score(case, score_document, lens_metrics or {})
        elif case["family"] == "COVENANT":
            metrics, score = covenant_score(case, score_document, covenant_metrics or {})
        elif case["family"] == "PARADOX":
            metrics, score = paradox_score(case, score_document, paradox_metrics or {})
        else:
            fail("unsupported_family", "family scoring is not implemented yet", family=case["family"])
    except VerificationError as exc:
        return invalid_receipt(world, case["id"], witness_digest, exc.diagnostic(), locals().get("replay"))
    except cre.CREError as exc:
        return invalid_receipt(world, case["id"], witness_digest, VerificationError(exc.code, exc.message, exc.context).diagnostic(), locals().get("replay"))

    return {
        "format": "afterimage-receipt/0.1",
        "valid": True,
        "bundle": world.bundle,
        "case": case["id"],
        "witness": witness_digest,
        "branch": replay.branch,
        "projection": replay.projection,
        "trace": replay.trace,
        "metrics": metrics,
        "score": score,
        "unlocks": [f"case:{case['id']}", *score_document.get("grants", [])],
        "diagnostics": [],
    }


def verify_witness(world_path: Path, witness_path: Path, facts: Iterable[str] = ()) -> dict[str, Any]:
    world = kit.verify_world(world_path)
    try:
        witness_bytes = witness_path.read_bytes()
    except OSError as exc:
        raise VerificationError("input_error", f"cannot read witness: {exc}") from exc
    return verify_witness_bytes(world, witness_bytes, str(witness_path), facts)


def emit(value: Any, pretty: bool) -> None:
    if pretty:
        print(json.dumps(cre.json_value(cre.normalize_value(value)), ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(cre.canonical_text(value))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("world", type=Path)
    parser.add_argument("witness", type=Path)
    parser.add_argument("--fact", action="append", default=[])
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args(argv)
    try:
        receipt = verify_witness(args.world, args.witness, args.fact)
        emit(receipt, args.pretty)
        return 0 if receipt["valid"] else 1
    except (VerificationError, kit.KitError) as exc:
        error = exc if isinstance(exc, VerificationError) else VerificationError(exc.code, exc.message, exc.context)
        emit({"type": "error", **error.diagnostic()}, args.pretty)
        return 2
    except OSError as exc:
        emit({"type": "error", "code": "io_error", "message": str(exc), "context": {}}, args.pretty)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
