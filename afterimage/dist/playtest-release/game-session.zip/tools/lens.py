#!/usr/bin/env python3
"""Finite law checker for the typed first-order LENS 0.1 slice language."""

from __future__ import annotations

import itertools
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "reference" / "python"))

import cre


class LensError(Exception):
    def __init__(self, code: str, message: str, context: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.context = context or {}


def require(condition: bool, code: str, message: str, **context: Any) -> None:
    if not condition:
        raise LensError(code, message, context)


def normalize(value: str) -> str:
    return " ".join(value.strip().lower().split())


def validate_contract(value: Any) -> dict[str, Any]:
    require(isinstance(value, dict) and set(value) == {"addresses", "entrances", "units", "provenance", "invalid_targets", "limits"}, "invalid_lens_contract", "LENS contract fields are invalid")
    require(isinstance(value["addresses"], list) and value["addresses"], "invalid_lens_contract", "LENS address table is empty")
    seen_sources: set[tuple[str, int]] = set()
    for index, item in enumerate(value["addresses"]):
        require(isinstance(item, dict) and set(item) == {"street", "number", "segment_id", "offset"}, "invalid_lens_contract", "LENS address row is invalid", index=index)
        require(isinstance(item["street"], str) and isinstance(item["segment_id"], str) and isinstance(item["number"], int) and not isinstance(item["number"], bool) and isinstance(item["offset"], int) and not isinstance(item["offset"], bool), "invalid_lens_contract", "LENS address row types are invalid", index=index)
        key = (normalize(item["street"]), item["number"])
        require(key not in seen_sources, "invalid_lens_contract", "LENS civic address is duplicated", index=index)
        seen_sources.add(key)
    require(isinstance(value["entrances"], list) and all(isinstance(item, dict) and set(item) == {"source", "target"} and isinstance(item["source"], str) and isinstance(item["target"], str) for item in value["entrances"]), "invalid_lens_contract", "LENS entrance table is invalid")
    require(isinstance(value["units"], list) and all(item is None or isinstance(item, str) for item in value["units"]), "invalid_lens_contract", "LENS unit domain is invalid")
    require(isinstance(value["provenance"], list) and all(isinstance(item, list) and all(isinstance(part, str) for part in item) for item in value["provenance"]), "invalid_lens_contract", "LENS provenance domain is invalid")
    require(isinstance(value["invalid_targets"], list), "invalid_lens_contract", "LENS invalid targets must be a list")
    require(isinstance(value["limits"], dict) and set(value["limits"]) == {"max_program_bytes", "max_nodes", "max_auxiliary_cells", "max_reductions"}, "invalid_lens_contract", "LENS limit fields are invalid")
    require(all(isinstance(item, int) and not isinstance(item, bool) and item > 0 for item in value["limits"].values()), "invalid_lens_contract", "LENS limits must be positive integers")
    return value


def node_count(value: Any) -> int:
    if isinstance(value, dict):
        return 1 + sum(node_count(item) for item in value.values())
    if isinstance(value, list):
        return 1 + sum(node_count(item) for item in value)
    return 1


def compile_program(value: Any, contract: dict[str, Any]) -> dict[str, Any]:
    require(isinstance(value, dict) and set(value) == {"format", "complement_schema", "get", "put"}, "invalid_lens_program", "LENS program fields are invalid")
    require(value["format"] == "afterimage-lens/0.1", "invalid_lens_program", "LENS program format is unsupported")
    cells = value["complement_schema"]
    require(isinstance(cells, list), "invalid_lens_program", "LENS complement schema must be a list")
    allowed_cells = {"unit": "option-text", "provenance": "text-list", "boundary_street": "text"}
    schema: dict[str, str] = {}
    for index, item in enumerate(cells):
        require(isinstance(item, dict) and set(item) == {"name", "type"} and item["name"] in allowed_cells and item["type"] == allowed_cells[item["name"]] and item["name"] not in schema, "invalid_lens_program", "LENS complement cell is invalid", index=index)
        schema[item["name"]] = item["type"]
    known_get = {"forward_address", "encode_entrance"}
    known_put = {"reverse_address", "decode_entrance", "restore"}
    require(isinstance(value["get"], list) and isinstance(value["put"], list), "invalid_lens_program", "LENS pipelines must be lists")
    get_ops: dict[str, dict[str, Any]] = {}
    for item in value["get"]:
        require(isinstance(item, dict) and item.get("op") in known_get and item["op"] not in get_ops, "invalid_lens_program", "LENS get operation is invalid")
        if item["op"] == "forward_address":
            require(set(item) == {"op", "table"} and item["table"] == "addresses", "invalid_lens_program", "forward_address fields are invalid")
        else:
            require(set(item) == {"op", "table"} and item["table"] == "entrances", "invalid_lens_program", "encode_entrance fields are invalid")
        get_ops[item["op"]] = item
    put_ops: dict[str, dict[str, Any]] = {}
    for item in value["put"]:
        require(isinstance(item, dict) and item.get("op") in known_put and item["op"] not in put_ops, "invalid_lens_program", "LENS put operation is invalid")
        if item["op"] == "reverse_address":
            require(set(item) == {"op", "table", "disambiguation"} and item["table"] == "addresses" and item["disambiguation"] in {None, "boundary_street"}, "invalid_lens_program", "reverse_address fields are invalid")
        elif item["op"] == "decode_entrance":
            require(set(item) == {"op", "table"} and item["table"] == "entrances", "invalid_lens_program", "decode_entrance fields are invalid")
        else:
            require(set(item) == {"op", "fields"} and isinstance(item["fields"], list) and len(set(item["fields"])) == len(item["fields"]) and set(item["fields"]) <= {"unit", "provenance"}, "invalid_lens_program", "restore fields are invalid")
        put_ops[item["op"]] = item
    size = len(cre.canonical_bytes(value))
    nodes = node_count(value)
    limits = contract["limits"]
    require(size <= limits["max_program_bytes"] and nodes <= limits["max_nodes"] and len(schema) <= limits["max_auxiliary_cells"], "lens_limit", "LENS program exceeds a static resource limit")
    return {"value": value, "schema": schema, "get_ops": get_ops, "put_ops": put_ops, "bytes": size, "nodes": nodes}


def complement(compiled: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    result = {}
    if "unit" in compiled["schema"]:
        result["unit"] = source["unit"]
    if "provenance" in compiled["schema"]:
        result["provenance"] = source["provenance"]
    if "boundary_street" in compiled["schema"]:
        result["boundary_street"] = normalize(source["street_name"])
    return result


def get_view(compiled: dict[str, Any], contract: dict[str, Any], source: dict[str, Any]) -> tuple[dict[str, Any] | None, int]:
    reductions = 0
    if set(compiled["get_ops"]) != {"forward_address", "encode_entrance"}:
        return None, reductions
    row = None
    for candidate in contract["addresses"]:
        reductions += 1
        if normalize(candidate["street"]) == normalize(source["street_name"]) and candidate["number"] == source["number"]:
            row = candidate
            break
    if row is None:
        return None, reductions
    entrance_code = None
    if source["entrance"] is not None:
        for candidate in contract["entrances"]:
            reductions += 1
            if candidate["source"] == source["entrance"]:
                entrance_code = candidate["target"]
                break
        if entrance_code is None:
            return None, reductions
    return {"segment_id": row["segment_id"], "offset": row["offset"], "entrance_code": entrance_code}, reductions


def put_view(compiled: dict[str, Any], contract: dict[str, Any], source: dict[str, Any], target: dict[str, Any]) -> tuple[dict[str, Any] | None, int]:
    reductions = 0
    if set(compiled["put_ops"]) != {"reverse_address", "decode_entrance", "restore"} or not isinstance(target, dict) or set(target) != {"segment_id", "offset", "entrance_code"}:
        return None, reductions
    candidates = []
    for row in contract["addresses"]:
        reductions += 1
        if row["segment_id"] == target["segment_id"] and row["offset"] == target["offset"]:
            candidates.append(row)
    if not candidates:
        return None, reductions
    comp = complement(compiled, source)
    reverse = compiled["put_ops"]["reverse_address"]
    chosen = None
    if reverse["disambiguation"] == "boundary_street" and "boundary_street" in comp:
        chosen = next((row for row in candidates if normalize(row["street"]) == comp["boundary_street"]), None)
    chosen = chosen or sorted(candidates, key=lambda row: (normalize(row["street"]), row["number"]))[0]
    entrance = None
    if target["entrance_code"] is not None:
        for row in contract["entrances"]:
            reductions += 1
            if row["target"] == target["entrance_code"]:
                entrance = row["source"]
                break
        if entrance is None:
            return None, reductions
    restore = set(compiled["put_ops"]["restore"]["fields"])
    result = {
        "number": chosen["number"], "street_name": chosen["street"], "entrance": entrance,
        "unit": comp.get("unit") if "unit" in restore else None,
        "provenance": comp.get("provenance", []) if "provenance" in restore else [],
    }
    return result, reductions


def source_domain(contract: dict[str, Any]) -> list[dict[str, Any]]:
    values = []
    entrances = [None, *[item["source"] for item in contract["entrances"]]]
    for row, unit, entrance, provenance in itertools.product(contract["addresses"], contract["units"], entrances, contract["provenance"]):
        values.append({"number": row["number"], "street_name": row["street"], "unit": unit, "entrance": entrance, "provenance": provenance})
    return sorted(values, key=cre.canonical_bytes)


def target_domain(contract: dict[str, Any]) -> list[dict[str, Any]]:
    routes = {(row["segment_id"], row["offset"]) for row in contract["addresses"]}
    entrances = [None, *[item["target"] for item in contract["entrances"]]]
    return sorted([{"segment_id": segment, "offset": offset, "entrance_code": entrance} for (segment, offset), entrance in itertools.product(routes, entrances)], key=cre.canonical_bytes)


def counterexample(law: str, source: dict[str, Any], edit: Any = None, expected: Any = None, observed: Any = None) -> LensError:
    return LensError("lens_counterexample", "LENS law failed on bounded domain", {"law": law, "source": source, "edit": edit, "expected": expected, "observed": observed})


def verify_program(program: Any, contract_value: Any) -> dict[str, int]:
    contract = validate_contract(contract_value)
    compiled = compile_program(program, contract)
    worst = 0
    sources = source_domain(contract)
    targets = target_domain(contract)
    for source in sources:
        view, reductions = get_view(compiled, contract, source)
        worst = max(worst, reductions)
        if view is None:
            raise counterexample("GetTotal", source, observed=None)
        restored, reductions = put_view(compiled, contract, source, view)
        worst = max(worst, reductions)
        if not cre.same_value(restored, source):
            raise counterexample("GetPut", source, view, source, restored)
        for target in targets:
            updated, reductions = put_view(compiled, contract, source, target)
            worst = max(worst, reductions)
            if updated is None:
                raise counterexample("PutTotal", source, target, "success", None)
            observed, reductions = get_view(compiled, contract, updated)
            worst = max(worst, reductions)
            if not cre.same_value(observed, target):
                raise counterexample("PutGet", source, target, target, observed)
            stable, reductions = put_view(compiled, contract, updated, target)
            worst = max(worst, reductions)
            if not cre.same_value(stable, updated):
                raise counterexample("Stability", source, target, updated, stable)
            if updated["unit"] != source["unit"] or updated["provenance"] != source["provenance"]:
                raise counterexample("Provenance", source, target, {"unit": source["unit"], "provenance": source["provenance"]}, {"unit": updated["unit"], "provenance": updated["provenance"]})
        for target in contract["invalid_targets"]:
            before = cre.canonical_bytes(source)
            observed, reductions = put_view(compiled, contract, source, target)
            worst = max(worst, reductions)
            if observed is not None or before != cre.canonical_bytes(source):
                raise counterexample("InvalidAtomic", source, target, None, observed)
    require(worst <= contract["limits"]["max_reductions"], "lens_limit", "LENS program exceeds reduction limit", observed=worst)
    return {"program_nodes": compiled["nodes"], "auxiliary_schema_cells": len(compiled["schema"]), "worst_reductions": worst, "domain_sources": len(sources), "domain_targets": len(targets)}
